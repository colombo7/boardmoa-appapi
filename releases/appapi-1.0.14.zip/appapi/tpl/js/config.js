/* 관리 화면: 앱이 이 사이트에 접속할 수 있는지 스스로 확인해 결과만 보여 준다 */
// <load> 는 스크립트를 페이지 머리(head)에 넣을 수 있어, 상자가 그려진 뒤에 시작한다
function appapiCheckConnection() {
	var box = document.getElementById('appapi-status');
	if (!box) return;
	var text = box.querySelector('.appapi-status-text');
	// 문구는 관리 화면 언어로 (appapi.admin.view.php 가 data-text 로 넘긴다)
	var words = {};
	try { words = JSON.parse(box.getAttribute('data-text') || '{}'); } catch (e) {}
	function t(ko) { return words[ko] || ko; }
	function show(ok, message) {
		text.innerHTML = '';
		var mark = document.createElement('strong');
		mark.style.color = ok ? '#1a7f37' : '#cf222e';
		mark.textContent = ok ? t('✓ 정상') : t('✗ 접속 안 됨');
		text.appendChild(mark);
		text.appendChild(document.createTextNode(' — ' + message));
		if (!ok) {
			var link = document.createElement('a');
			link.href = box.getAttribute('data-link');
			link.target = '_blank';
			link.textContent = t('직접 열어 보기');
			text.appendChild(document.createTextNode(' '));
			text.appendChild(link);
		}
	}
	function handle(status, body) {
		var data = null;
		try { data = JSON.parse(body); } catch (e) {}
		if (data && data.ok) {
			var d = data.data || {};
			show(true, t('앱에서 이 사이트를 추가할 수 있습니다') + (d.api_version ? ' (' + t('모듈') + ' ' + d.api_version + ')' : ''));
		} else if (data && data.error) {
			show(false, data.error.message || data.error.code || t('응답 오류'));
		} else {
			show(false, t('응답이 앱 형식이 아닙니다') + ' (HTTP ' + status + ')');
		}
	}
	var url = box.getAttribute('data-url');
	// 쿠키 없이 묻는다 (앱처럼): 브라우저의 로그인 쿠키가 API 로 가지 않게
	if (window.fetch) {
		var done = false;
		var timer = setTimeout(function () { if (!done) { done = true; show(false, t('응답이 너무 늦습니다')); } }, 15000);
		fetch(url, { credentials: 'omit', cache: 'no-store' }).then(function (r) {
			return r.text().then(function (body) { if (!done) { done = true; clearTimeout(timer); handle(r.status, body); } });
		}, function () { if (!done) { done = true; clearTimeout(timer); show(false, t('서버에 접속하지 못했습니다')); } });
		return;
	}
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);
	xhr.timeout = 15000;
	xhr.onload = function () { handle(xhr.status, xhr.responseText); };
	xhr.onerror = function () { show(false, t('서버에 접속하지 못했습니다')); };
	xhr.ontimeout = function () { show(false, t('응답이 너무 늦습니다')); };
	xhr.send();
}
if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', appapiCheckConnection);
} else {
	appapiCheckConnection();
}
