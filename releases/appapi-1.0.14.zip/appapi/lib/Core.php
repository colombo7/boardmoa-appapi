<?php
namespace AppApi;

/**
 * 사이트 코어(구 XE 1.x 또는 Rhymix) 부트스트랩과 엔진별 차이 흡수.
 *
 * 원칙: 코어 파일은 고치지 않고, 권한 판단은 코어 코드에 맡긴다.
 */
class Core
{
	/** @var string 'xe' | 'rhymix' */
	public static $engine;

	/** @var array 앱이 보낸 요청 값 (쿼리 + JSON 본문) */
	public static $params = array();

	/** @var string 원래 HTTP 메서드 */
	public static $method = 'GET';

	/** @var string 사이트 기본 주소 (예: https://www.kgpa.org/) */
	public static $base_url;

	/** @var string 이 API 의 주소 (예: https://www.kgpa.org/modules/appapi/api.php) */
	public static $api_url;

	public static function boot()
	{
		self::$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
		self::$params = self::readParams();

		// 코어는 우리가 명시적으로 넣는 값만 보게 한다 (비밀번호 등이 Context 로 새지 않도록).
		$_GET = $_POST = $_REQUEST = array();
		// 앱은 쿠키를 쓰지 않는다. 브라우저(관리 화면의 연결 확인 등)가 보낸 로그인 쿠키를 코어가 보지 않게 버린다:
		// 그 세션으로 요청을 처리한 뒤 endRequestSession() 이 지우면, 웹에 로그인한 사람(관리자)이 로그아웃된다.
		$_COOKIE = array();
		unset($_SERVER['HTTP_COOKIE']);
		unset($_SERVER['CONTENT_TYPE'], $_SERVER['HTTP_CONTENT_TYPE']);
		$GLOBALS['HTTP_RAW_POST_DATA'] = '';
		$_SERVER['REQUEST_METHOD'] = 'GET';

		// 코어는 SCRIPT_NAME 으로 사이트 주소를 계산한다. 사이트 index.php 인 것처럼 맞춘다.
		// 모듈(modules/appapi/api.php)로 설치돼도, 루트의 appapi/index.php 로 불려도 사이트 루트를 찾는다.
		$site_dir = self::siteDir();
		$script_file = str_replace('\\', '/', realpath($_SERVER['SCRIPT_FILENAME']) ?: $_SERVER['SCRIPT_FILENAME']);
		$relative = substr($script_file, strlen(str_replace('\\', '/', $site_dir)));
		$script_name = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
		$original_script_name = $script_name;
		$base_path = rtrim(substr($script_name, 0, max(0, strlen($script_name) - strlen($relative))), '/');
		$_SERVER['SCRIPT_NAME'] = $_SERVER['PHP_SELF'] = $base_path . '/index.php';
		$_SERVER['SCRIPT_FILENAME'] = $site_dir . '/index.php';
		$_SERVER['REQUEST_URI'] = $base_path . '/';
		chdir($site_dir);

		if (!defined('__XE__'))
		{
			define('__XE__', true);
		}
		ob_start();
		require $site_dir . '/config/config.inc.php';
		self::$engine = defined('RX_VERSION') ? 'rhymix' : 'xe';

		self::applyAppLang();
		$oContext = \Context::getInstance();
		$oContext->init();
		if (!\Context::isInstalled())
		{
			throw new ApiError(503, 'not_installed', 'site is not installed');
		}
		\Mobile::setMobile(false);
		self::captchaAsMobile();
		\Context::loadLang('./modules/member/lang');

		$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
		self::$base_url = $scheme . '://' . $_SERVER['HTTP_HOST'] . $base_path . '/';
		self::$api_url = $scheme . '://' . $_SERVER['HTTP_HOST'] . $original_script_name;
	}

	/**
	 * Rhymix 스팸 방지 CAPTCHA 의 '대상 기기'에서 앱은 휴대폰(mobile)이다.
	 * 위에서 PC 화면으로 맞춘 것(setMobile(false), 게시판 동작도 엔진이 PC 로 되돌린다)은 그대로 두고, 이 요청에서 엔진이 읽는
	 * 스팸 방지 설정의 사본만 바꾼다: PC 칸을 휴대폰 칸 값으로. 그러면 엔진의 판단(isCaptchaEnabled — 앱에 미리 알리는
	 * captchaRequired, 로그인의 checkCaptcha, 글·댓글 쓰기 때 엔진 트리거)이 모두 휴대폰 기준이 되고, 레이아웃·스킨 같은
	 * 다른 PC/휴대폰 동작은 바뀌지 않는다. 저장된 설정(DB·캐시)은 건드리지 않는다.
	 */
	private static function captchaAsMobile()
	{
		if (self::$engine !== 'rhymix' || !class_exists('ModuleModel'))
		{
			return;
		}
		try
		{
			$config = \ModuleModel::getModuleConfig('spamfilter');
			if (!is_object($config) || empty($config->captcha) || !is_object($config->captcha) || !isset($config->captcha->target_devices)
				|| !is_array($config->captcha->target_devices) || !isset($GLOBALS['__ModuleConfig__']['spamfilter']))
			{
				return;
			}
			$copy = unserialize(serialize($config));
			$copy->captcha->target_devices['pc'] = !empty($config->captcha->target_devices['mobile']);
			$GLOBALS['__ModuleConfig__']['spamfilter'] = $copy;
		}
		catch (\Throwable $e)
		{
			error_log('[appapi] captcha device: ' . $e->getMessage());
		}
	}

	/**
	 * 앱이 보낸 언어(X-App-Lang)를 엔진 언어로 (모듈 0.10.19~). 웹의 언어 바꾸기와 같이 엔진이 init 에서 읽는
	 * lang_type 쿠키 값을 이 요청 안에서만 넣는다 (앱 요청은 쿠키를 쓰지 않고, 응답에 쿠키를 내보내지도 않는다).
	 * 그러면 메뉴·게시판 이름의 다국어 값($user_lang->…), 다국어 글, 분류·추가 항목 이름, 엔진 문구가 그 언어로 나온다.
	 * 사이트가 그 언어를 켜 두지 않았으면 영어로, 영어도 없으면 넣지 않는다(사이트 기본 언어). 머리말이 없는 예전 앱은 그대로다.
	 */
	private static function applyAppLang()
	{
		$requested = isset($_SERVER['HTTP_X_APP_LANG']) ? trim((string)$_SERVER['HTTP_X_APP_LANG']) : '';
		$requested = preg_replace('/[^A-Za-z_-]/', '', substr($requested, 0, 16));
		// 앱 설정 '게시판 언어: 사이트 기본 언어' (모듈 1.0.12~): 내용은 사이트 기본 언어 그대로 (앱에 보내는 문구는 그대로 앱 언어)
		if ($requested === '' || self::siteContentLang())
		{
			return;
		}
		$supported = @\Context::loadLangSelected();
		if (!is_array($supported) || !$supported)
		{
			return;
		}
		$code = self::engineLangCode($requested, array_keys($supported));
		if ($code !== null)
		{
			$_COOKIE['lang_type'] = $code;
		}
	}

	/**
	 * 앱이 게시판 내용을 사이트 기본 언어로 달라고 했는지 (X-Content-Lang: site)
	 */
	public static function siteContentLang()
	{
		return isset($_SERVER['HTTP_X_CONTENT_LANG']) && strtolower(trim((string)$_SERVER['HTTP_X_CONTENT_LANG'])) === 'site';
	}

	/**
	 * 앱 언어 코드(ko, en, ja, es, pt-BR, de, fr, it, vi, id, zh-Hant, zh-Hans …) → 사이트가 켠 엔진 언어 코드.
	 * 엔진마다 이름이 다르다: 일본어 XE 1.11 jp · Rhymix ja, 번체 중국어 zh-TW · 간체 중국어 zh-CN, 포르투갈어 pt-BR 또는 pt.
	 * 사이트에 없는 언어면 영어(사이트가 영어를 켰을 때), 그것도 없으면 null(사이트 기본 언어 그대로).
	 */
	public static function engineLangCode($requested, array $enabled)
	{
		$lower = array();
		foreach ($enabled as $c)
		{
			$lower[strtolower((string)$c)] = (string)$c;
		}
		$req = strtolower(str_replace('_', '-', (string)$requested));
		$base = explode('-', $req)[0];
		if ($base === 'ja')
		{
			$candidates = array('ja', 'jp');
		}
		elseif ($base === 'zh')
		{
			$candidates = preg_match('/hant|tw|hk|mo/', $req) ? array('zh-tw', 'zh-hk') : array('zh-cn');
		}
		elseif ($base === 'pt')
		{
			$candidates = array($req, 'pt-br', 'pt');
		}
		else
		{
			$candidates = array($req, $base);
		}
		foreach ($candidates as $c)
		{
			if (isset($lower[$c]))
			{
				return $lower[$c];
			}
		}
		return isset($lower['en']) ? $lower['en'] : null;
	}

	/**
	 * 다국어 이름($user_lang->…)을 지금 언어 값으로. 엔진이 웹 화면을 내보낼 때 하는 바꾸기와 같다.
	 */
	public static function userLang($text)
	{
		$text = (string)$text;
		if (strpos($text, '$user_lang->') === false)
		{
			return $text;
		}
		if (method_exists('Context', 'replaceUserLang'))
		{
			return (string)\Context::replaceUserLang($text);
		}
		$oModuleController = getController('module');
		if ($oModuleController && method_exists($oModuleController, 'replaceDefinedLangCode'))
		{
			$oModuleController->replaceDefinedLangCode($text);
		}
		return $text;
	}

	/**
	 * 엔진 언어 코드(XE jp·zh-CN·zh-TW, Rhymix ja 등)를 앱 언어 코드로. 앱에 없는 언어면 null.
	 */
	public static function appLangCode($code)
	{
		$code = strtolower(str_replace('_', '-', trim((string)$code)));
		$base = explode('-', $code)[0];
		if ($base === 'zh')
		{
			return preg_match('/-(tw|hk|mo|hant)\b/', $code) ? 'zh-Hant' : 'zh-Hans';
		}
		if ($base === 'jp')
		{
			return 'ja';
		}
		if ($base === 'pt')
		{
			return 'pt-BR';
		}
		return in_array($base, array('ko', 'en', 'ja', 'es', 'de', 'fr', 'it', 'vi', 'id'), true) ? $base : null;
	}

	/**
	 * 제목처럼 글자로만 보이는 값: 다국어 치환 뒤 엔진이 저장할 때 바꾼 HTML 문자(&amp; 등)를 되돌린다.
	 */
	public static function plainLang($text)
	{
		return html_entity_decode(self::userLang($text), ENT_QUOTES, 'UTF-8');
	}

	/**
	 * config/config.inc.php 가 있는 곳(사이트 루트)까지 위로 올라가며 찾는다.
	 */
	private static function siteDir()
	{
		$dir = realpath(APPAPI_DIR);
		for ($i = 0; $i < 4 && $dir; $i++)
		{
			$dir = dirname($dir);
			if (file_exists($dir . '/config/config.inc.php'))
			{
				return $dir;
			}
		}
		throw new ApiError(500, 'site_not_found', 'site root not found');
	}

	private static function readParams()
	{
		$params = $_GET;
		$content_type = $_SERVER['CONTENT_TYPE'] ?? ($_SERVER['HTTP_CONTENT_TYPE'] ?? '');
		if (stripos($content_type, 'json') !== false)
		{
			$json = json_decode(file_get_contents('php://input'), true);
			if (is_array($json))
			{
				$params = array_merge($params, $json);
			}
		}
		elseif ($_POST)
		{
			$params = array_merge($params, $_POST);
		}
		return $params;
	}

	public static function param($key, $default = null)
	{
		return isset(self::$params[$key]) ? self::$params[$key] : $default;
	}

	/**
	 * 글자 하나로 받아야 하는 값. 배열(title[]=… 처럼 보낸 것)은 받지 않고 $default 로 본다:
	 * (string) 로 바꾸면 "Array" 라는 글자가 저장되기 때문이다. 숫자·참거짓은 글자로 바꾼다.
	 * 배열이 맞는 값(photos·choices·extra_vars·fields·agreements)은 param() 으로 따로 받는다.
	 */
	public static function str($key, $default = '')
	{
		$value = self::param($key);
		if ($value === null || is_array($value) || is_object($value))
		{
			return $default;
		}
		if (is_bool($value))
		{
			return $value ? '1' : '';
		}
		return (string)$value;
	}

	public static function intParam($key, $default = 0)
	{
		$value = self::param($key);
		if (is_array($value) || is_object($value))
		{
			return $default;
		}
		return ($value !== null && ctype_digit((string)$value)) ? (int)$value : $default;
	}

	/**
	 * 이번 요청 동안만 해당 회원으로 로그인한 상태를 만든다.
	 * 웹 세션과 같은 경로(setSessionInfo)를 타므로 그룹·권한 계산이 웹과 같다.
	 */
	public static function loginAs($member_srl)
	{
		if (self::$engine === 'rhymix')
		{
			\Rhymix\Framework\Session::login($member_srl, false);
		}
		else
		{
			$_SESSION['member_srl'] = $member_srl;
			$_SESSION['is_logged'] = true;
			$_SESSION['ipaddress'] = $_SERVER['REMOTE_ADDR'];
		}
		getController('member')->setSessionInfo();

		$logged_info = \Context::get('logged_info');
		return $logged_info && (int)$logged_info->member_srl === (int)$member_srl;
	}

	/**
	 * 앱은 쿠키 세션을 쓰지 않는다. 요청마다 생긴 PHP 세션은 응답 전에 폐기한다.
	 */
	public static function endRequestSession()
	{
		if (session_status() === PHP_SESSION_ACTIVE)
		{
			$_SESSION = array();
			@session_destroy();
		}
		if (!headers_sent() && function_exists('header_remove'))
		{
			header_remove('Set-Cookie');
		}
	}

	/**
	 * 앱 전용 테이블에 쓸 PDO 연결. 두 엔진의 DB 클래스 API 가 달라 직접 연결한다.
	 */
	public static function pdo()
	{
		static $pdo = null;
		if ($pdo)
		{
			return $pdo;
		}

		if (self::$engine === 'rhymix')
		{
			$c = \Rhymix\Framework\Config::get('db.master');
			$host = $c['host'];
			$port = $c['port'];
			$user = $c['user'];
			$pass = $c['pass'];
			$name = $c['database'];
			$socket = $c['socket'] ?? '';
		}
		else
		{
			$c = \Context::getDBInfo()->master_db;
			$host = $c['db_hostname'];
			$port = $c['db_port'];
			$user = $c['db_userid'];
			$pass = $c['db_password'];
			$name = $c['db_database'];
			$socket = '';
		}

		$dsn = $socket ? "mysql:unix_socket=$socket;dbname=$name" : "mysql:host=$host;port=" . ($port ?: 3306) . ";dbname=$name";
		$pdo = new \PDO($dsn . ';charset=utf8', $user, $pass, array(
			\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
			\PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
			\PDO::ATTR_EMULATE_PREPARES => false,
		));
		return $pdo;
	}

	/**
	 * 서버만 아는 서명 키 (썸네일 주소 서명 등). DB 접속 정보에서 만들어 따로 저장하지 않는다.
	 */
	public static function secret()
	{
		static $secret = null;
		if ($secret === null)
		{
			if (self::$engine === 'rhymix')
			{
				$c = \Rhymix\Framework\Config::get('db.master');
				$seed = $c['pass'] . '|' . $c['database'] . '|' . $c['prefix'];
			}
			else
			{
				$c = \Context::getDBInfo()->master_db;
				$seed = $c['db_password'] . '|' . $c['db_database'] . '|' . $c['db_table_prefix'];
			}
			$secret = hash('sha256', 'appapi|' . $seed);
		}
		return $secret;
	}

	public static function tablePrefix()
	{
		if (self::$engine === 'rhymix')
		{
			return \Rhymix\Framework\Config::get('db.master.prefix');
		}
		return \Context::getDBInfo()->master_db['db_table_prefix'];
	}

	/**
	 * 사이트별 설정 (appapi/config.php, 없으면 기본값).
	 */
	public static function config($key = null)
	{
		static $config = null;
		if ($config === null)
		{
			$config = array(
				'access_ttl' => 3600,
				'refresh_ttl' => 86400 * 365,
				'site_name' => '',
				'theme_color' => '',
				'logo_url' => '',
				'icon_url' => '',
				// 이름 표시(lib/Names.php): 작성자 기본값·게시판별, 추천인(같게/따로), 쪽지·친구. 비어 있으면 예전 설정을 따른다
				'name_display' => '',
				'board_name_display' => array(),
				'voter_same' => '',
				'voter_name_display' => '',
				'voter_board_name_display' => array(),
				'message_name_display' => '',
				// 예전 설정 (1.0.2 까지, 저장된 사이트만): 작성자·추천인 이름. nick_name = 닉네임만, nick_name_user_name = 닉네임(이름)
				'voter_name' => '',
				'author_name' => '',
				// 다른 회원 정보 보기(앱, 1.0.5~): group = 같은 그룹 회원(기본), member = 로그인한 회원, admin = 관리자만
				'member_info_view' => 'group',
			);
			if (file_exists(APPAPI_DIR . '/config.php'))
			{
				$custom = include APPAPI_DIR . '/config.php';
				if (is_array($custom))
				{
					$config = array_merge($config, $custom);
				}
			}
			// 관리자 화면(앱 연동 설정)에서 저장한 값이 가장 우선
			$saved = getModel('module')->getModuleConfig('appapi');
			if (is_object($saved))
			{
				foreach (array('site_name', 'theme_color', 'logo_url', 'icon_url', 'voter_name', 'author_name', 'name_display', 'voter_same', 'voter_name_display', 'message_name_display', 'member_info_view') as $name)
				{
					if (isset($saved->$name) && trim((string)$saved->$name) !== '')
					{
						$config[$name] = trim((string)$saved->$name);
					}
				}
				foreach (array('board_name_display', 'voter_board_name_display') as $name)
				{
					if (isset($saved->$name) && (is_array($saved->$name) || is_object($saved->$name)))
					{
						$config[$name] = (array)$saved->$name;
					}
				}
			}
		}
		return $key === null ? $config : ($config[$key] ?? null);
	}

	/**
	 * 앱에 보낼 회원 이름. 게시판별·사이트 기본 이름 표시 설정을 따른다 (lib/Names.php).
	 * 비회원(member_srl 0)·익명 글(음수)은 엔진이 준 이름 그대로.
	 * @param int $module_srl 그 글·댓글·추천이 속한 게시판 (모르면 0 → 사이트 기본값)
	 * @param string $scope author(작성자) | voter(추천인) | message(쪽지·친구, 게시판 없음)
	 */
	public static function displayName($nick_name, $member_srl, $module_srl, $scope = 'author')
	{
		$nick_name = (string)$nick_name;
		if ((int)$member_srl <= 0)
		{
			return $nick_name;
		}
		$mode = self::nameMode((int)$module_srl, $scope);
		if ($mode === \appapiNames::NICK)
		{
			return $nick_name;
		}
		return \appapiNames::format($mode, $nick_name, self::userName((int)$member_srl));
	}

	/** 게시판의 이름 표시 방식 (요청 안에서는 게시판마다 한 번만 정한다) */
	public static function nameMode($module_srl, $scope = 'author')
	{
		static $cache = array();
		$key = $module_srl . ':' . $scope;
		if (!isset($cache[$key]))
		{
			$module_info = $module_srl > 0 ? Board::boardOf($module_srl) : null;
			$cache[$key] = \appapiNames::mode(self::config(), $module_info, $scope);
		}
		return $cache[$key];
	}

	/** 회원 실명 (요청 안에서는 한 번만 읽는다) */
	public static function userName($member_srl)
	{
		static $cache = array();
		if (!isset($cache[$member_srl]))
		{
			$stmt = self::pdo()->prepare('SELECT user_name FROM `' . self::tablePrefix() . 'member` WHERE member_srl = ?');
			$stmt->execute(array($member_srl));
			$cache[$member_srl] = trim(html_entity_decode((string)$stmt->fetchColumn(), ENT_QUOTES, 'UTF-8'));
		}
		return $cache[$member_srl];
	}

	/**
	 * 상대 주소(./files/..., /files/..., files/...)를 사이트 절대 주소로 바꾼다.
	 */
	public static function absoluteUrl($url)
	{
		$url = trim((string)$url);
		if ($url === '' || preg_match('#^(data:|mailto:|tel:|//)#i', $url))
		{
			return $url;
		}
		if (preg_match('#^https?:#i', $url))
		{
			return preg_replace('#(?<=[^:/])/(\./)+#', '/', $url);
		}
		if ($url[0] === '/')
		{
			$p = parse_url(self::$base_url);
			return $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '') . $url;
		}
		return self::$base_url . preg_replace('#^\./#', '', $url);
	}

	public static function absolutizeHtml($html)
	{
		return preg_replace_callback('/\b(src|href|poster)\s*=\s*(["\'])(.*?)\2/i', function ($m) {
			return $m[1] . '=' . $m[2] . Core::absoluteUrl(html_entity_decode($m[3], ENT_QUOTES)) . $m[2];
		}, $html);
	}

	public static function isoTime($ymdhis)
	{
		if (!$ymdhis)
		{
			return null;
		}
		$t = ztime($ymdhis);
		return $t ? date('c', $t) : null;
	}
}
