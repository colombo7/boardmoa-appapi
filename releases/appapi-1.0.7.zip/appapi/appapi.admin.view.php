<?php
/**
 * 앱 연동 설정 화면
 */
class appapiAdminView extends appapi
{
	function init()
	{
		$this->setTemplatePath($this->module_path . 'tpl');
	}

	function dispAppapiAdminConfig()
	{
		$config = getModel('module')->getModuleConfig('appapi');
		if (!is_object($config))
		{
			$config = new stdClass;
		}
		$view = new stdClass;
		foreach (array('site_name', 'theme_color', 'logo_url', 'icon_url', 'share_site', 'member_info_view') as $key)
		{
			$view->$key = htmlspecialchars(isset($config->$key) ? (string)$config->$key : '', ENT_QUOTES, 'UTF-8');
		}
		Context::set('appapi_config', $view);
		Context::set('appapi_names', $this->nameSettings($config));
		Context::set('appapi_url', htmlspecialchars(Context::getDefaultUrl() . 'modules/appapi/api.php?r=site', ENT_QUOTES, 'UTF-8'));
		// 관리 화면이 스스로 접속해 보는 주소 (지금 연 주소와 같은 곳이어야 브라우저가 막지 않는다)
		Context::set('appapi_check_url', htmlspecialchars(Context::getRequestUri() . 'modules/appapi/api.php?r=site', ENT_QUOTES, 'UTF-8'));
		Context::set('appapi_engine', defined('RX_VERSION') ? 'Rhymix ' . RX_VERSION : 'XE ' . __XE_VERSION__);

		// 모듈 업데이트: [업데이트 확인]을 눌렀을 때만 밖(github)에 묻는다
		require_once __DIR__ . '/appapi.updater.php';
		Context::set('appapi_version', appapiUpdater::currentVersion());
		$update = Context::get('check_update') ? appapiUpdater::check() : null;
		if ($update)
		{
			foreach (array('notes', 'error', 'latest', 'date') as $key)
			{
				$update[$key] = htmlspecialchars((string)$update[$key], ENT_QUOTES, 'UTF-8');
			}
			$update['problems'] = array_map(function ($path) { return htmlspecialchars($path, ENT_QUOTES, 'UTF-8'); }, $update['problems']);
		}
		Context::set('appapi_update', $update ? (object)$update : null);
		// 값이 든 문구는 여기서 만든다 (템플릿 {…} 안에는 {0} 을 못 쓴다)
		$latest = $update ? $update['latest'] : '';
		Context::set('appapi_text', array(
			'is_newer' => appapiText::t('배포된 최신 버전({0})보다 새 버전입니다. 업데이트할 것이 없습니다.', $latest),
			'update_to' => appapiText::t('{0} 로 업데이트', $latest),
			'confirm' => htmlspecialchars(json_encode(appapiText::t('{0} 로 업데이트할까요? 지금 파일은 files/appapi_backup 에 백업됩니다.', $latest), JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8'),
		));
		Context::set('tr', new appapiTextView());
		// 연결 확인 스크립트 문구
		$js = array();
		foreach (array('✓ 정상', '✗ 접속 안 됨', '직접 열어 보기', '앱에서 이 사이트를 추가할 수 있습니다', '모듈', '응답 오류', '응답이 앱 형식이 아닙니다', '서버에 접속하지 못했습니다', '응답이 너무 늦습니다') as $ko)
		{
			$js[$ko] = appapiText::t($ko);
		}
		Context::set('appapi_js_text', htmlspecialchars(json_encode($js, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8'));
		$result = isset($_SESSION['appapi_update_result']) ? $_SESSION['appapi_update_result'] : null;
		unset($_SESSION['appapi_update_result']);
		if ($result)
		{
			$result['message'] = htmlspecialchars((string)$result['message'], ENT_QUOTES, 'UTF-8');
			$result['backup'] = htmlspecialchars((string)$result['backup'], ENT_QUOTES, 'UTF-8');
		}
		Context::set('appapi_update_result', $result ? (object)$result : null);
		$this->setTemplateFile('config');
	}

	/**
	 * 이름 표시 설정 화면 값 (lib/Names.php). 가입 때 이름을 받지 않는 사이트는 collects=false (고르는 칸을 숨긴다).
	 * 고르는 칸(라디오)과 게시판 표는 여기서 HTML 로 만든다 (게시판이 수백 개여도 템플릿이 가볍게).
	 * 게시판은 모듈 분류별로 묶고, 분류·게시판 이름 순으로 늘어놓는다.
	 */
	private function nameSettings($config)
	{
		require_once __DIR__ . '/lib/Text.php';
		require_once __DIR__ . '/lib/Names.php';
		$saved = array();
		foreach (array('name_display', 'voter_same', 'voter_name_display', 'message_name_display', 'author_name', 'voter_name') as $key)
		{
			$saved[$key] = isset($config->$key) ? trim((string)$config->$key) : '';
		}
		foreach (array('board_name_display', 'voter_board_name_display') as $key)
		{
			$saved[$key] = isset($config->$key) ? (array)$config->$key : array();
		}
		$esc = function ($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); };
		$labels = array(appapiNames::NICK => appapiText::t('닉네임'), appapiNames::NAME => appapiText::t('이름'), appapiNames::BOTH => appapiText::t('닉네임(이름)'));
		$result = new stdClass;
		$result->collects = appapiNames::collectsUserName();
		// 새 설정을 저장한 적이 없으면 예전 설정에서 (Names::siteDefault·voterSame)
		$author_default = appapiNames::siteDefault($saved, 'author');
		$voter_default = appapiNames::siteDefault($saved, 'voter');
		$message = appapiNames::valid($saved['message_name_display']) ? $saved['message_name_display'] : '';
		$result->voter_same = appapiNames::voterSame($saved);
		$radios = function ($name, $current, $toggle) use ($labels, $esc) {
			$html = '';
			foreach ($labels as $value => $label)
			{
				$html .= '<label class="x_inline"><input type="radio"' . ($toggle ? ' class="appapi-toggle"' : '') . ' name="' . $name . '" value="' . $value . '"'
					. ($current === $value ? ' checked="checked"' : '') . ' /> ' . $esc($label) . '</label> ';
			}
			return $html;
		};
		$result->default_radios = $radios('name_display', $author_default, false);
		$result->voter_default_radios = $radios('voter_name_display', $voter_default, false);
		$result->message_radios = $radios('message_name_display', $message, true);
		$result->message_effective = $message === '' ? $esc(appapiText::t('(기본: {0})', $labels[appapiNames::NICK])) : '';

		$args = new stdClass;
		$args->module = 'board';
		$boards = getModel('module')->getMidList($args);
		$srls = array();
		foreach ((array)$boards as $board)
		{
			$srls[] = (int)$board->module_srl;
		}
		$result->board_count = count($srls);
		$extra = $srls ? (array)getModel('module')->getModuleExtraVars($srls) : array();
		$categories = array();
		foreach ((array)getModel('module')->getModuleCategories() as $category)
		{
			$categories[(int)$category->module_category_srl] = $this->userLang($category->title);
		}
		$groups = array();
		foreach ((array)$boards as $board)
		{
			$srl = (int)$board->module_srl;
			$category = (int)$board->module_category_srl;
			$key = isset($categories[$category]) ? $category : 0;
			if (!isset($groups[$key]))
			{
				$groups[$key] = (object)array('title' => $key ? $categories[$key] : '', 'boards' => array());
			}
			$vars = isset($extra[$srl]) ? $extra[$srl] : null;
			$groups[$key]->boards[] = (object)array(
				'module_srl' => $srl,
				'mid' => (string)$board->mid,
				'title' => $this->userLang($board->browser_title),
				'anonymous' => $vars && isset($vars->use_anonymous) && $vars->use_anonymous === 'Y',
			);
		}
		// 분류 이름 순, 분류 없는 게시판은 맨 뒤. 분류 안에서는 게시판 이름 순
		uksort($groups, function ($a, $b) use ($groups) {
			if (!$a || !$b)
			{
				return $a ? -1 : ($b ? 1 : 0);
			}
			return strnatcasecmp($groups[$a]->title, $groups[$b]->title);
		});
		foreach ($groups as $group)
		{
			usort($group->boards, function ($a, $b) {
				return strnatcasecmp($a->title, $b->title) ?: strcmp($a->mid, $b->mid);
			});
		}
		$groups = array_values($groups);
		$result->author_table = $this->boardTable($groups, 'board_names', 'name_display', appapiNames::boardModes($saved, 'author'), $author_default, $labels);
		$result->voter_table = $this->boardTable($groups, 'voter_board_names', 'voter_name_display', appapiNames::boardModes($saved, 'voter'), $voter_default, $labels);
		// 화면 스크립트(js/names.js) 문구
		$js = array('modes' => $labels);
		foreach (array('(기본: {0})', '아무것도 고르지 않은 게시판은 사이트 기본값({0})으로 표시됩니다.') as $ko)
		{
			$js[$ko] = appapiText::t($ko);
		}
		$result->js_text = $esc(json_encode($js, JSON_UNESCAPED_UNICODE));
		return $result;
	}

	/**
	 * 게시판별 이름 표 (찾기 칸·[전체 해제(기본값)]·열마다 [전체]·줄마다 라디오 무리 <$field>[번호]·'(기본: …)').
	 * 고르지 않은 줄은 아무것도 보내지 않아 기본값($default_name 라디오)을 따른다. 익명 게시판은 고르는 칸이 없다.
	 * 게시판이 많아도 화면이 길어지지 않게 표는 접어 둔다(<details>, 눌러서 펼침). 접혀 있어도 라디오 값은 그대로 저장된다.
	 */
	private function boardTable($groups, $field, $default_name, $modes, $default, $labels)
	{
		$esc = function ($text) { return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8'); };
		$has_categories = false;
		foreach ($groups as $group)
		{
			$has_categories = $has_categories || $group->title !== '';
		}
		$effective = $esc(appapiText::t('(기본: {0})', $labels[$default]));
		$board_count = 0;
		$chosen = 0;
		foreach ($groups as $group)
		{
			foreach ($group->boards as $board)
			{
				$board_count++;
				$chosen += (!$board->anonymous && !empty($modes[$board->module_srl])) ? 1 : 0;
			}
		}
		$html = '<details class="appapi-board-fold"><summary style="cursor:pointer;margin-bottom:8px">'
			. $esc(appapiText::t('게시판 목록 ({0}개, 따로 정한 게시판 {1}개) — 눌러서 펼치기·접기', $board_count, $chosen)) . '</summary>'
			. '<div class="appapi-board-block" data-default="' . $default_name . '">'
			. '<p><input type="search" class="appapi-board-filter" placeholder="' . $esc(appapiText::t('게시판 이름이나 mid 로 찾기')) . '" style="width:40%" /> '
			. '<button type="button" class="x_btn x_btn-small" data-all="">' . $esc(appapiText::t('전체 해제(기본값)')) . '</button></p>'
			. '<table class="x_table x_table-striped x_table-hover" style="width:auto;min-width:60%"><thead><tr><th scope="col">' . $esc(appapiText::t('게시판')) . '</th><th scope="col">mid</th>';
		foreach ($labels as $value => $label)
		{
			$html .= '<th scope="col" style="text-align:center">' . $esc($label) . '<br /><button type="button" class="x_btn x_btn-mini" data-all="' . $value . '">' . $esc(appapiText::t('전체')) . '</button></th>';
		}
		$html .= '<th scope="col"></th></tr></thead>';
		foreach ($groups as $group)
		{
			$html .= '<tbody>';
			if ($has_categories)
			{
				$html .= '<tr class="appapi-group"><th colspan="6">' . $esc($group->title !== '' ? $group->title : appapiText::t('분류 없음')) . '</th></tr>';
			}
			foreach ($group->boards as $board)
			{
				$html .= '<tr class="appapi-board" data-search="' . $esc(mb_strtolower($board->title . ' ' . $board->mid, 'UTF-8')) . '"><td>' . $esc($board->title) . '</td><td><code>' . $esc($board->mid) . '</code></td>';
				if ($board->anonymous)
				{
					$html .= '<td colspan="4"><span class="x_help-inline">' . $esc(appapiText::t('익명 게시판 (이름을 드러내지 않습니다)')) . '</span></td></tr>';
					continue;
				}
				$mode = isset($modes[$board->module_srl]) ? $modes[$board->module_srl] : '';
				foreach ($labels as $value => $label)
				{
					$html .= '<td style="text-align:center"><input type="radio" class="appapi-toggle" name="' . $field . '[' . $board->module_srl . ']" value="' . $value . '"'
						. ($mode === $value ? ' checked="checked"' : '') . ' aria-label="' . $esc($board->title . ': ' . $label) . '" /></td>';
				}
				$html .= '<td class="appapi-effective" style="opacity:.6">' . ($mode === '' ? $effective : '') . '</td></tr>';
			}
			$html .= '</tbody>';
		}
		$html .= '</table><p class="x_help-block appapi-board-hint">' . $esc(appapiText::t('아무것도 고르지 않은 게시판은 사이트 기본값({0})으로 표시됩니다.', $labels[$default])) . '</p></div></details>';
		return $html;
	}

	/** 다국어 이름($user_lang->…)을 관리 화면 언어 값으로 */
	private function userLang($text)
	{
		$text = (string)$text;
		if (strpos($text, '$user_lang->') === false)
		{
			return $text;
		}
		if (method_exists('Context', 'replaceUserLang'))
		{
			return (string)Context::replaceUserLang($text);
		}
		$oModuleController = getController('module');
		if ($oModuleController && method_exists($oModuleController, 'replaceDefinedLangCode'))
		{
			$oModuleController->replaceDefinedLangCode($text);
		}
		return $text;
	}
}
