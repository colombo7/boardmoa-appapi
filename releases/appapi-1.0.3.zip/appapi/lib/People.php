<?php
namespace AppApi;

/**
 * 글쓴이 이름을 눌렀을 때의 메뉴: 회원 정보 보기, 작성글 보기, 쪽지 보내기, 친구 등록, 메일 보내기.
 *
 * 메뉴는 웹과 같은 엔진 함수(member 의 getMemberMenu)를 실행해 만든다. 쪽지·친구는 쪽지 모듈 설정(Rhymix)이나
 * member_communication 애드온(XE), 상대의 쪽지 받기 설정, 이미 친구인지에 따라 엔진이 붙이거나 뺀다.
 * 앱이 처리할 수 있는 항목만 골라 보낸다(관리자용 추적 메뉴 등은 뺀다).
 */
class People
{
	public static function menu()
	{
		$member_srl = Core::intParam('member_srl');
		$mid = self::mid();
		if (!$member_srl)
		{
			throw new ApiError(400, 'missing_member_srl', 'member_srl is required');
		}
		$oModule = Board::run('', 'getMemberMenu', array('module' => 'member', 'target_srl' => $member_srl, 'cur_mid' => $mid), false);
		$actions = array();
		foreach ((array)$oModule->get('menus') as $menu)
		{
			$url = html_entity_decode((string)($menu->url ?? ''), ENT_QUOTES, 'UTF-8');
			$label = strip_tags((string)($menu->str ?? ''));
			$action = self::actionFromUrl($url, $member_srl, $mid);
			if ($action)
			{
				$action['label'] = $label;
				$actions[$action['type']] = $action;
			}
		}
		return array('member_srl' => $member_srl, 'actions' => array_values($actions));
	}

	/** 엔진이 만든 메뉴 주소를 앱 동작으로 바꾼다. 모르는 메뉴는 null */
	private static function actionFromUrl($url, $member_srl, $mid)
	{
		if (stripos($url, 'mailto:') === 0)
		{
			return array('type' => 'email', 'email' => substr($url, 7));
		}
		$query = array();
		parse_str((string)parse_url($url, PHP_URL_QUERY), $query);
		$act = isset($query['act']) ? (string)$query['act'] : '';
		if ($act === 'dispMemberInfo')
		{
			return array('type' => 'info');
		}
		if ($act === 'dispCommunicationSendMessage')
		{
			return array('type' => 'message');
		}
		if ($act === 'dispCommunicationAddFriend')
		{
			return array('type' => 'friend');
		}
		// 작성글 보기: Rhymix 는 ?mid=..&member_srl=.., XE 는 ?mid=..&search_target=nick_name&search_keyword=..
		// 짧은 주소를 쓰는 사이트는 게시판 이름이 경로에 있다 (/conf_schedule?member_srl=..)
		if (empty($query['mid']))
		{
			$path = trim((string)parse_url($url, PHP_URL_PATH), '/');
			$last = $path === '' ? '' : basename($path);
			if (preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,59}$/', $last) && $last !== 'index')
			{
				$query['mid'] = $last;
			}
		}
		if ($act === '' && !empty($query['mid']) && (!empty($query['member_srl']) || (($query['search_target'] ?? '') === 'nick_name' && isset($query['search_keyword']))))
		{
			$search = !empty($query['member_srl'])
				? array('member_srl' => (string)(int)$query['member_srl'])
				: array('search_target' => 'nick_name', 'search_keyword' => (string)$query['search_keyword']);
			return array('type' => 'documents', 'mid' => (string)$query['mid'], 'search' => $search);
		}
		return null;
	}

	/** 회원 정보: 웹과 같은 엔진 함수로, 관리자가 공개로 정한 항목만 (자기 정보·관리자는 엔진 규칙대로) */
	public static function info()
	{
		$member_srl = Core::intParam('member_srl');
		if (!$member_srl)
		{
			throw new ApiError(400, 'missing_member_srl', 'member_srl is required');
		}
		Board::run('', 'dispMemberInfo', array('module' => 'member', 'member_srl' => $member_srl), false);
		$member = (array)\Context::get('memberInfo');
		if (empty($member['member_srl']) || (int)$member['member_srl'] !== $member_srl)
		{
			throw new ApiError(404, 'member_not_found', Auth::lang('msg_not_founded'));
		}
		$fields = array();
		foreach ((array)\Context::get('displayDatas') as $item)
		{
			$name = (string)($item->name ?? '');
			// 사진 항목은 따로 보낸다, 비밀번호류는 엔진이 이미 뺐다
			if (in_array($name, array('profile_image', 'image_name', 'image_mark', 'nick_name'), true))
			{
				continue;
			}
			$value = $item->value ?? '';
			$value = is_array($value) ? implode(', ', $value) : (string)$value;
			$text = trim(html_entity_decode(strip_tags(str_replace(array('<br>', '<br />', '<br/>'), "\n", $value)), ENT_QUOTES, 'UTF-8'));
			if ($text === '')
			{
				continue;
			}
			$fields[] = array('title' => strip_tags((string)($item->title ?? $name)), 'value' => $text);
		}
		$image = getModel('member')->getProfileImage($member_srl);
		return array(
			'member_srl' => $member_srl,
			'nick_name' => html_entity_decode((string)($member['nick_name'] ?? ''), ENT_QUOTES, 'UTF-8'),
			'profile_image' => $image ? Core::absoluteUrl($image->src) : null,
			'regdate' => isset($member['regdate']) ? Core::isoTime($member['regdate']) : null,
			'fields' => $fields,
		);
	}

	/** 쪽지 보내기: 엔진의 쪽지 보내기 (받는 사람 설정·권한·포인트는 엔진이) */
	public static function sendMessage()
	{
		$receiver = Core::intParam('receiver_srl');
		$title = trim(Core::str('title'));
		$content = trim(str_replace(array("\r\n", "\r"), "\n", Core::str('content')));
		if (!$receiver || $title === '' || $content === '')
		{
			throw new ApiError(400, 'missing_content', \appapiText::t('제목과 내용을 입력해 주세요.'));
		}
		self::runAction('procCommunicationSendMessage', array(
			'receiver_srl' => $receiver,
			'title' => mb_substr($title, 0, 200),
			'content' => nl2br(htmlspecialchars(mb_substr($content, 0, 10000), ENT_QUOTES, 'UTF-8')),
		));
		return array('sent' => true);
	}

	/** 친구 등록: 엔진의 친구 추가 (기본 친구 그룹) */
	public static function addFriend()
	{
		$target = Core::intParam('target_srl');
		if (!$target)
		{
			throw new ApiError(400, 'missing_member_srl', 'target_srl is required');
		}
		self::runAction('procCommunicationAddFriend', array('target_srl' => $target));
		return array('added' => true);
	}

	private static function runAction($act, array $vars)
	{
		try
		{
			Board::run('', $act, array('module' => 'communication', 'window_type' => 'self') + $vars, false, true);
		}
		catch (ApiError $e)
		{
			// 쪽지를 받지 않는 회원, 이미 친구 등 엔진이 거절한 이유를 그대로 보여 준다
			throw new ApiError(400, 'action_failed', $e->getMessage());
		}
	}

	private static function mid()
	{
		$mid = Core::str('mid', '');
		return preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,59}$/', $mid) ? $mid : '';
	}
}
