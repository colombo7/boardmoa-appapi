<?php
namespace AppApi;

/**
 * 내 활동: 작성글, 작성댓글, 스크랩, 저장함(임시 저장 글), 로그인 기록, 쪽지함, 친구.
 *
 * 어떤 메뉴를 보일지는 웹의 회원 메뉴(엔진이 모은 logged_info->menu_list)를 그대로 따른다.
 * 관리자가 끈 기능(Rhymix 회원 설정), 깔리지 않은 모듈(로그인 기록·내 댓글)은 웹처럼 빠진다.
 * 목록은 웹과 같은 엔진 화면을 실행해서 받는다 (자기 것만 나오는 것도 엔진이 정한다).
 */
class My
{
	/** 앱이 다룰 수 있는 회원 메뉴: 엔진 act → 앱 기능 이름 (작성댓글은 Rhymix 기본 또는 sejin7940_comment 모듈) */
	private static $features = array(
		'dispMemberOwnDocument' => 'documents',
		'dispMemberOwnComment' => 'comments',
		'dispSejin7940_commentOwnComment' => 'comments',
		'dispMemberScrappedDocument' => 'scraps',
		'dispMemberSavedDocument' => 'saved',
		// 로그인 기록(dispLoginlogHistories → logins)은 앱에 보이지 않는다: 해킹 추적 등 관리자용 자료라 사용자에게는 필요하지 않다고 봤다(2026-10-23).
		// 기록은 사이트에 그대로 쌓이고, my.logins 도 남겨 둔다(메뉴에 없으니 부르면 feature_disabled). 다시 보이려면 이 줄을 되살린다.
		'dispCommunicationMessages' => 'messages',
		'dispCommunicationFriend' => 'friends',
	);

	public static function menu()
	{
		// 회원 메뉴는 모듈을 실행할 때(초기화 단계의 트리거·애드온) 모인다. XE 의 쪽지·친구 메뉴를 붙이는
		// member_communication 애드온은 회원(member) 모듈에서는 붙이지 않아서, 쪽지함 화면으로 실행한다.
		// 쪽지가 꺼진 사이트면 그 화면은 거절되지만 메뉴는 그 전에 모이므로 그대로 읽는다.
		try
		{
			self::run('communication', 'dispCommunicationMessages', array('message_type' => 'R', 'page' => 1));
		}
		catch (ApiError $e)
		{
		}
		$logged_info = \Context::get('logged_info');
		if (empty($logged_info->menu_list))
		{
			self::run('member', 'dispMemberInfo', array());
			$logged_info = \Context::get('logged_info');
		}
		$items = array();
		foreach ((array)($logged_info->menu_list ?? array()) as $act => $label)
		{
			if (!isset(self::$features[$act]) || isset($items[self::$features[$act]]))
			{
				continue;
			}
			$key = self::$features[$act];
			$items[$key] = array('key' => $key, 'title' => trim(strip_tags(Auth::lang((string)$label))));
			if ($key === 'messages')
			{
				$items[$key]['badge'] = self::unreadMessages((int)$logged_info->member_srl);
			}
		}
		return array('items' => array_values($items));
	}

	/** 작성글: 웹의 "작성 글 보기"와 같은 목록 */
	public static function documents()
	{
		self::requireFeature('documents');
		self::run('member', 'dispMemberOwnDocument', array('page' => self::page()));
		$documents = array();
		foreach ((array)\Context::get('document_list') as $oDocument)
		{
			if (is_object($oDocument) && method_exists($oDocument, 'isExists') && $oDocument->isExists())
			{
				$documents[] = Board::summaryWithBoard($oDocument);
			}
		}
		return self::paged('documents', $documents);
	}

	/** 작성댓글: Rhymix 기본 "작성 댓글 보기" 또는 sejin7940_comment 모듈의 "내 댓글" */
	public static function comments()
	{
		self::requireFeature('comments');
		$acts = self::menuActs();
		if (isset($acts['dispMemberOwnComment']))
		{
			self::run('member', 'dispMemberOwnComment', array('page' => self::page()));
		}
		else
		{
			self::run('sejin7940_comment', 'dispSejin7940_commentOwnComment', array('page' => self::page()));
		}
		$rows = array();
		$document_srls = array();
		foreach ((array)\Context::get('comment_list') as $item)
		{
			$get = function ($key) use ($item) {
				return is_object($item) && method_exists($item, 'get') ? $item->get($key) : ($item->$key ?? null);
			};
			$document_srl = (int)$get('document_srl');
			$rows[] = array(
				'comment_srl' => (int)$get('comment_srl'),
				'document_srl' => $document_srl,
				'content' => self::plainText((string)$get('content'), 200),
				'regdate' => Core::isoTime((string)$get('regdate')),
				'is_secret' => $get('is_secret') === 'Y',
			);
			$document_srls[$document_srl] = true;
		}
		// 원글 제목·게시판: 글을 한 번에 불러온다
		$documents = $document_srls ? getModel('document')->getDocuments(array_keys($document_srls), false, false) : array();
		$comments = array();
		foreach ($rows as $row)
		{
			$oDocument = $documents[$row['document_srl']] ?? null;
			if (!$oDocument || !$oDocument->isExists())
			{
				continue;
			}
			$board = Board::boardOf((int)$oDocument->get('module_srl'));
			$comments[] = $row + array(
				'document_title' => html_entity_decode($oDocument->getTitleText(), ENT_QUOTES, 'UTF-8'),
				'mid' => $board ? $board->mid : null,
				'board_title' => $board ? Core::userLang($board->browser_title) : null,
			);
		}
		return self::paged('comments', $comments);
	}

	/** 스크랩: 웹의 "스크랩 보기" (Rhymix 는 폴더별) */
	public static function scraps()
	{
		self::requireFeature('scraps');
		$folder_srl = Core::intParam('folder_srl');
		self::run('member', 'dispMemberScrappedDocument', array('page' => self::page(), 'folder_srl' => $folder_srl ?: null));
		$rows = (array)\Context::get('document_list');
		$srls = array();
		foreach ($rows as $row)
		{
			$srls[] = (int)($row->document_srl ?? 0);
		}
		$documents = $srls ? getModel('document')->getDocuments(array_filter($srls), false, false) : array();
		$items = array();
		foreach ($rows as $row)
		{
			$document_srl = (int)($row->document_srl ?? 0);
			$oDocument = $documents[$document_srl] ?? null;
			$board = ($oDocument && $oDocument->isExists()) ? Board::boardOf((int)$oDocument->get('module_srl')) : null;
			$items[] = array(
				'document_srl' => $document_srl,
				// 스크랩할 때 저장된 제목·글쓴이 (원글이 지워져도 남는다)
				'title' => html_entity_decode((string)($row->title ?? ''), ENT_QUOTES, 'UTF-8'),
				// 원글이 남아 있으면 그 게시판의 이름 표시 설정을 따른다 (익명·비회원 글은 저장된 이름 그대로)
				'author' => ($oDocument && $oDocument->isExists())
					? Core::displayName(html_entity_decode((string)($row->nick_name ?? ''), ENT_QUOTES, 'UTF-8'), (int)$oDocument->get('member_srl'), (int)$oDocument->get('module_srl'))
					: html_entity_decode((string)($row->nick_name ?? ''), ENT_QUOTES, 'UTF-8'),
				'scrapped_at' => Core::isoTime((string)($row->regdate ?? '')),
				'mid' => $board ? $board->mid : null,
				'board_title' => $board ? Core::userLang($board->browser_title) : null,
				'exists' => $board !== null,
			);
		}
		$folders = array();
		foreach ((array)\Context::get('scrap_folders') as $folder)
		{
			$folders[] = array('folder_srl' => (int)$folder->folder_srl, 'name' => html_entity_decode((string)$folder->name, ENT_QUOTES, 'UTF-8'));
		}
		$result = self::paged('documents', $items);
		$result['folders'] = $folders;
		$result['folder_srl'] = $folder_srl ?: ($folders ? (int)(\Context::get('folder_srl') ?: $folders[0]['folder_srl']) : 0);
		return $result;
	}

	/** 스크랩 빼기: 엔진의 스크랩 삭제 (자기 스크랩만 지워진다) */
	public static function deleteScrap()
	{
		self::requireFeature('scraps');
		$document_srl = Core::intParam('document_srl');
		if (!$document_srl)
		{
			throw new ApiError(400, 'missing_document_srl', 'document_srl is required');
		}
		try
		{
			Board::run('', 'procMemberDeleteScrap', array('module' => 'member', 'document_srl' => $document_srl), false, true);
		}
		catch (ApiError $e)
		{
			throw new ApiError(400, 'action_failed', $e->getMessage());
		}
		return array('deleted' => true);
	}

	/** 저장함: 임시 저장한 글 (웹 편집기의 "임시 저장"). 이어 쓰기는 document.source / document.update 로 */
	public static function saved()
	{
		self::requireFeature('saved');
		self::run('member', 'dispMemberSavedDocument', array('page' => self::page()));
		$documents = array();
		foreach ((array)\Context::get('document_list') as $oDocument)
		{
			if (is_object($oDocument) && method_exists($oDocument, 'isExists') && $oDocument->isExists())
			{
				$item = Board::summaryWithBoard($oDocument);
				// 저장함은 자기 글이라 요약을 늘 보여 준다
				$item['summary'] = self::plainText((string)$oDocument->get('content'), 120);
				$documents[] = $item;
			}
		}
		return self::paged('documents', $documents);
	}

	/** 저장함에서 지우기: 엔진의 임시 글 지우기 (자기 임시 글만) */
	public static function deleteSaved()
	{
		self::requireFeature('saved');
		$document_srl = Core::intParam('document_srl');
		if (!$document_srl)
		{
			throw new ApiError(400, 'missing_document_srl', 'document_srl is required');
		}
		try
		{
			Board::run('', 'procMemberDeleteSavedDocument', array('module' => 'member', 'document_srl' => $document_srl), false, true);
		}
		catch (ApiError $e)
		{
			throw new ApiError(400, 'action_failed', $e->getMessage());
		}
		return array('deleted' => true);
	}

	/**
	 * 로그인 기록: loginlog 모듈의 "로그인 기록" (앱 로그인도 같은 엔진 로그인을 거쳐 남는다).
	 * 기간: period = 1m(기본)·3m·1y·all. 웹 화면은 기간을 나누지 않아, 같은 모듈 질의(getLoginlogList)에 자기 회원 번호와 시작 날짜를 넣어 부른다.
	 */
	public static function logins()
	{
		self::requireFeature('logins');
		$periods = array('1m' => '-1 month', '3m' => '-3 months', '1y' => '-1 year', 'all' => null);
		$period = Core::str('period', '1m');
		if (!array_key_exists($period, $periods))
		{
			$period = '1m';
		}
		$args = new \stdClass;
		$args->member_srl = (int)\Context::get('logged_info')->member_srl;
		$args->page = self::page();
		$args->list_count = 30;
		$args->page_count = 10;
		$args->sort_index = 'log_srl';
		$args->order_type = 'desc';
		if ($periods[$period])
		{
			$args->daterange_start = date('YmdHis', strtotime($periods[$period]));
		}
		$output = executeQueryArray('loginlog.getLoginlogList', $args);
		$items = array();
		foreach ((array)$output->data as $row)
		{
			$items[] = array(
				'regdate' => Core::isoTime((string)($row->regdate ?? '')),
				'ipaddress' => (string)($row->ipaddress ?? ''),
				'succeeded' => ($row->is_succeed ?? 'Y') === 'Y',
				'platform' => (string)($row->platform ?? ''),
				'browser' => (string)($row->browser ?? ''),
			);
		}
		return array(
			'logins' => $items,
			'page' => max(1, (int)$output->page),
			'total_pages' => max(1, (int)$output->total_page),
			'total_count' => (int)$output->total_count,
			'period' => $period,
		);
	}

	/** 쪽지함: R 받은 쪽지, S 보낸 쪽지, T 보관함 (웹의 쪽지함과 같은 목록) */
	public static function messages()
	{
		self::requireFeature('messages');
		$type = self::messageType();
		self::run('communication', 'dispCommunicationMessages', array('message_type' => $type, 'page' => self::page()));
		$items = array();
		foreach ((array)\Context::get('message_list') as $row)
		{
			$items[] = array(
				'message_srl' => (int)$row->message_srl,
				'title' => html_entity_decode((string)($row->title ?? ''), ENT_QUOTES, 'UTF-8'),
				// 받은 쪽지·보관함은 보낸 사람, 보낸 쪽지는 받는 사람
				'member_srl' => (int)($row->member_srl ?? 0),
				// 이름: 쪽지·친구 이름 표시 설정
				'nick_name' => Core::displayName(html_entity_decode((string)($row->nick_name ?? ''), ENT_QUOTES, 'UTF-8'), (int)($row->member_srl ?? 0), 0, 'message'),
				'regdate' => Core::isoTime((string)($row->regdate ?? '')),
				'readed' => ($row->readed ?? 'N') === 'Y',
			);
		}
		$result = self::paged('messages', $items);
		$result['message_type'] = $type;
		$result['unread'] = self::unreadMessages((int)\Context::get('logged_info')->member_srl);
		return $result;
	}

	/** 쪽지 하나: 엔진이 받는 사람·보낸 사람인지 확인하고, 받은 쪽지면 읽음으로 바꾼다 */
	public static function message()
	{
		self::requireFeature('messages');
		$message_srl = Core::intParam('message_srl');
		if (!$message_srl)
		{
			throw new ApiError(400, 'missing_message_srl', 'message_srl is required');
		}
		self::run('communication', 'dispCommunicationMessages', array('message_type' => self::messageType(), 'message_srl' => $message_srl));
		$message = \Context::get('message');
		if (!$message || (int)$message->message_srl !== $message_srl)
		{
			throw new ApiError(404, 'message_not_found', Auth::lang('msg_not_founded'));
		}
		$me = (int)\Context::get('logged_info')->member_srl;
		$sent = (int)$message->sender_srl === $me && $message->message_type === 'S';
		return array(
			'message_srl' => $message_srl,
			'message_type' => (string)$message->message_type,
			'title' => html_entity_decode((string)$message->title, ENT_QUOTES, 'UTF-8'),
			'content' => self::plainText((string)$message->content, 20000),
			'regdate' => Core::isoTime((string)$message->regdate),
			// 상대: 보낸 쪽지면 받는 사람, 아니면 보낸 사람 (엔진이 상대 회원 정보를 붙여 준다)
			'member_srl' => $sent ? (int)$message->receiver_srl : (int)$message->sender_srl,
			'nick_name' => Core::displayName(html_entity_decode((string)($message->nick_name ?? ''), ENT_QUOTES, 'UTF-8'), $sent ? (int)$message->receiver_srl : (int)$message->sender_srl, 0, 'message'),
			'sent' => $sent,
		);
	}

	/** 쪽지 지우기 */
	public static function deleteMessage()
	{
		self::requireFeature('messages');
		self::messageAction('procCommunicationDeleteMessage');
		return array('deleted' => true);
	}

	/** 쪽지 보관함으로 옮기기 */
	public static function storeMessage()
	{
		self::requireFeature('messages');
		self::messageAction('procCommunicationStoreMessage');
		return array('stored' => true);
	}

	/** 친구 목록 (그룹별) */
	public static function friends()
	{
		self::requireFeature('friends');
		$group = Core::intParam('friend_group_srl');
		self::run('communication', 'dispCommunicationFriend', array('friend_group_srl' => $group ?: null, 'page' => self::page()));
		$groups = array();
		foreach ((array)\Context::get('friend_group_list') as $row)
		{
			$groups[] = array('friend_group_srl' => (int)$row->friend_group_srl, 'title' => html_entity_decode((string)$row->title, ENT_QUOTES, 'UTF-8'));
		}
		$items = array();
		foreach ((array)\Context::get('friend_list') as $row)
		{
			$target = (int)($row->target_srl ?? 0);
			$image = $target ? getModel('member')->getProfileImage($target) : null;
			$items[] = array(
				'friend_srl' => (int)$row->friend_srl,
				'member_srl' => $target,
				// 이름: 쪽지·친구 이름 표시 설정
				'nick_name' => Core::displayName(html_entity_decode((string)($row->nick_name ?? ''), ENT_QUOTES, 'UTF-8'), $target, 0, 'message'),
				'profile_image' => $image ? Core::absoluteUrl($image->src) : null,
				'group_title' => html_entity_decode((string)($row->group_title ?? ''), ENT_QUOTES, 'UTF-8'),
				'regdate' => Core::isoTime((string)($row->regdate ?? '')),
			);
		}
		$result = self::paged('friends', $items);
		$result['groups'] = $groups;
		return $result;
	}

	/** 친구 빼기: 엔진의 친구 삭제 (자기 친구 목록에서만 지워진다) */
	public static function deleteFriend()
	{
		self::requireFeature('friends');
		$friend_srl = Core::intParam('friend_srl');
		if (!$friend_srl)
		{
			throw new ApiError(400, 'missing_friend_srl', 'friend_srl is required');
		}
		self::action('procCommunicationDeleteFriend', array('friend_srl_list' => (string)$friend_srl));
		return array('deleted' => true);
	}

	// ---- 내부

	private static function messageType()
	{
		$type = Core::str('message_type', 'R');
		return in_array($type, array('R', 'S', 'T'), true) ? $type : 'R';
	}

	private static function messageAction($act)
	{
		$message_srl = Core::intParam('message_srl');
		if (!$message_srl)
		{
			throw new ApiError(400, 'missing_message_srl', 'message_srl is required');
		}
		self::action($act, array('message_srl' => $message_srl));
	}

	/** 쪽지·친구 쓰기 동작: 웹이 AJAX 로 부르는 동작이라 JSON 방식으로 실행, 엔진이 거절한 이유를 그대로 */
	private static function action($act, array $vars)
	{
		try
		{
			Board::run('', $act, array('module' => 'communication') + $vars, false, true);
		}
		catch (ApiError $e)
		{
			throw new ApiError(400, 'action_failed', $e->getMessage());
		}
	}

	/** 안 읽은 받은 쪽지 수. XE 의 getNewMessage 는 쪽지를 읽음으로 바꿔 버려 쓰지 않고 수만 센다 */
	private static function unreadMessages($member_srl)
	{
		if (!$member_srl)
		{
			return 0;
		}
		$table = '`' . Core::tablePrefix() . 'member_message`';
		$stmt = Core::pdo()->prepare("SELECT COUNT(*) FROM $table WHERE receiver_srl = ? AND message_type = 'R' AND readed = 'N'");
		$stmt->execute(array($member_srl));
		return (int)$stmt->fetchColumn();
	}


	/** 웹 회원 메뉴에 없는 기능은 웹처럼 막는다 */
	private static function requireFeature($key)
	{
		if (!in_array($key, array_map(function ($item) { return $item['key']; }, self::menu()['items']), true))
		{
			throw new ApiError(403, 'feature_disabled', Auth::lang('msg_not_permitted'));
		}
	}

	private static function menuActs()
	{
		$logged_info = \Context::get('logged_info');
		return (array)($logged_info->menu_list ?? array());
	}

	/**
	 * 회원 모듈 화면 실행. Rhymix 는 회원 전용 mid 를 강제하면(force_mid) 그 mid 가 아니면 이동만 하고 끝나므로 그 mid 로 부른다.
	 */
	public static function run($module, $act, array $vars)
	{
		$mid = '';
		// 회원 메뉴 주소를 고정한 사이트(Rhymix 회원 설정 mid + force_mid, 새로 설치하면 기본으로 켜진다)는 회원·쪽지·친구 화면을
		// 그 mid 에서만 그린다. 다른 주소면 엔진(MemberView::checkMidAndRedirect)이 목록을 만들지 않고 넘겨주기만 하므로 같은 mid 로 실행한다.
		if ($module === 'member' || $module === 'communication')
		{
			$config = getModel('member')->getMemberConfig();
			if (!empty($config->mid) && !empty($config->force_mid))
			{
				$mid = (string)$config->mid;
			}
		}
		return Board::run($mid, $act, array('module' => $module) + $vars, false);
	}

	private static function page()
	{
		return max(1, Core::intParam('page', 1));
	}

	private static function paged($key, array $items)
	{
		return array(
			$key => $items,
			'page' => max(1, (int)\Context::get('page')),
			'total_pages' => max(1, (int)\Context::get('total_page')),
			'total_count' => (int)\Context::get('total_count'),
		);
	}

	private static function plainText($html, $length)
	{
		$text = html_entity_decode(strip_tags(str_replace(array('<br>', '<br />', '<br/>', '</p>'), "\n", $html)), ENT_QUOTES, 'UTF-8');
		$text = trim(preg_replace("/[ \t]+/u", ' ', preg_replace("/\n{2,}/u", "\n", $text)));
		return mb_substr($text, 0, $length);
	}
}
