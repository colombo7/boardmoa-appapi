<?php
namespace AppApi;

/**
 * 조회수를 사이트 설정(문서 설정의 "조회수 올리기")대로 세기 위한 앱 접속 기록 (<prefix>appapi_views).
 *
 * 엔진은 "이 세션에서 이미 읽은 글"($_SESSION['readed_document'])로 다시 세지 않는데, 앱은 쿠키 세션을 쓰지 않아
 * 요청마다 새 세션이 되어 같은 글을 받을 때마다 조회수가 올랐다. 앱이 실행될 때마다 만드는 접속 번호
 * (X-BoardHub-Session)를 웹 브라우저 세션 대신 써서, 그 접속에서 읽은 글을 엔진에 알려 준다.
 * 세는 판단(매번/세션마다/한 번만/안 셈, 글쓴이 제외)은 그대로 엔진이 한다.
 */
class Views
{
	/** 기록을 남겨 두는 기간 (웹 세션처럼 오래 두지 않는다) */
	const LIFETIME = 86400;

	private static function table()
	{
		return Core::tablePrefix() . 'appapi_views';
	}

	public static function ensureTable()
	{
		Core::pdo()->exec('CREATE TABLE IF NOT EXISTS `' . self::table() . '` (
			`session_hash` CHAR(64) NOT NULL,
			`document_srl` BIGINT NOT NULL,
			`created` INT UNSIGNED NOT NULL,
			PRIMARY KEY (`session_hash`, `document_srl`),
			KEY `idx_created` (`created`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8');
	}

	/** 앱이 보낸 접속 번호 (없거나 형식이 다르면 null: 예전 앱은 지금처럼 매번 센다) */
	private static function sessionHash()
	{
		$id = isset($_SERVER['HTTP_X_BOARDHUB_SESSION']) ? (string)$_SERVER['HTTP_X_BOARDHUB_SESSION'] : '';
		if (!preg_match('/^[A-Za-z0-9-]{16,64}$/', $id))
		{
			return null;
		}
		// 회원과 묶는다: 한 접속 번호로 다른 계정이 먼저 읽어 두면 글읽기 포인트를 내지 않고 읽게 되므로
		$logged_info = \Context::get('logged_info');
		$member_srl = $logged_info && !empty($logged_info->member_srl) ? (int)$logged_info->member_srl : 0;
		return hash('sha256', 'appapi-view|' . $id . '|' . $member_srl);
	}

	/**
	 * 엔진이 글을 보이기 전에: 이 접속에서 이미 읽은 글이면 세션에 표시해 엔진이 다시 세지 않게 한다.
	 */
	public static function before($document_srl)
	{
		$hash = self::sessionHash();
		if (!$hash)
		{
			return;
		}
		try
		{
			self::ensureTable();
			$stmt = Core::pdo()->prepare('SELECT 1 FROM `' . self::table() . '` WHERE session_hash = ? AND document_srl = ? AND created > ?');
			$stmt->execute(array($hash, (int)$document_srl, time() - self::LIFETIME));
			if ($stmt->fetchColumn())
			{
				if (!isset($_SESSION['readed_document']) || !is_array($_SESSION['readed_document']))
				{
					$_SESSION['readed_document'] = array();
				}
				$_SESSION['readed_document'][(int)$document_srl] = true;
			}
		}
		catch (\Exception $e)
		{
			// 기록을 못 읽으면 웹처럼 세게 둔다 (글 보기는 막지 않는다)
		}
	}

	/** 글을 보인 뒤: 이 접속에서 읽었다고 기록한다 (웹에서 세션에 남기는 것과 같다) */
	public static function after($document_srl)
	{
		$hash = self::sessionHash();
		if (!$hash)
		{
			return;
		}
		try
		{
			$now = time();
			$stmt = Core::pdo()->prepare('INSERT INTO `' . self::table() . '` (session_hash, document_srl, created) VALUES (?, ?, ?)
				ON DUPLICATE KEY UPDATE created = created');
			$stmt->execute(array($hash, (int)$document_srl, $now));
			if (mt_rand(1, 100) === 1)
			{
				Core::pdo()->prepare('DELETE FROM `' . self::table() . '` WHERE created < ?')->execute(array($now - self::LIFETIME));
			}
		}
		catch (\Exception $e)
		{
		}
	}
}
