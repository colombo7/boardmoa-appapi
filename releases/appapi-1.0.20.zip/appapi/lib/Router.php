<?php
namespace AppApi;

class Router
{
	/**
	 * route => [허용 메서드, 로그인 필수 여부, 처리 함수]
	 * 로그인이 필수가 아닌 route 도 토큰이 오면 그 회원 권한으로 처리한다.
	 */
	private static $routes = array(
		'site' => array('GET', false, array('AppApi\Menu', 'site')),
		'menu' => array('GET', false, array('AppApi\Menu', 'menus')),
		'auth.login' => array('POST', null, array('AppApi\Auth', 'login')),
		'auth.refresh' => array('POST', null, array('AppApi\Auth', 'refresh')),
		'auth.logout' => array('POST', null, array('AppApi\Auth', 'logout')),
		// 로그인한 기기 (모듈 1.0.19~, 기능 devices)
		'auth.devices' => array('GET', true, array('AppApi\Auth', 'devices')),
		'auth.devices.revoke' => array('POST', true, array('AppApi\Auth', 'revokeDevice')),
		'me' => array('GET', true, array('AppApi\Auth', 'me')),
		'me.form' => array('GET', true, array('AppApi\Member', 'form')),
		'me.update' => array('POST', true, array('AppApi\Member', 'update')),
		'me.password' => array('POST', true, array('AppApi\Member', 'password')),
		'me.image' => array('POST', true, array('AppApi\Member', 'image')),
		'me.leave' => array('POST', true, array('AppApi\Member', 'leave')),
		'signup.form' => array('GET', false, array('AppApi\Member', 'signupForm')),
		'signup' => array('POST', null, array('AppApi\Member', 'signup')),
		'feed' => array('GET', false, array('AppApi\Board', 'feed')),
		'board' => array('GET', false, array('AppApi\Board', 'documents')),
		// 비밀번호로 여는 비회원 비밀글은 POST 로도 받는다 (모듈 0.10.17~, 비밀번호가 주소에 남지 않게)
		'document' => array('GET|POST', false, array('AppApi\Board', 'document')),
		'comments' => array('GET', false, array('AppApi\Board', 'comments')),
		'page' => array('GET', false, array('AppApi\Board', 'page')),
		'resolve' => array('GET', false, array('AppApi\Board', 'resolve')),
		'file' => array('GET', false, array('AppApi\Board', 'file')),
		'thumb' => array('GET', null, array('AppApi\Board', 'thumb')),
		// 비회원도 글쓰기 권한이 있으면 쓴다 (모듈 0.10.16~, 이름·비밀번호를 받는다. 권한은 엔진이 다시 확인)
		'document.write' => array('POST', false, array('AppApi\Write', 'insertDocument')),
		// 비회원 글·댓글은 비밀번호로 고치고 지운다 (모듈 0.10.17~, 토큰도 비밀번호도 없으면 예전처럼 login_required)
		'document.delete' => array('POST', false, array('AppApi\Write', 'deleteDocument')),
		'document.source' => array('GET|POST', false, array('AppApi\Write', 'documentSource')),
		'document.update' => array('POST', false, array('AppApi\Write', 'updateDocument')),
		'document.tempsave' => array('POST', true, array('AppApi\Write', 'tempSave')),
		'comment.write' => array('POST', false, array('AppApi\Write', 'insertComment')),
		'comment.delete' => array('POST', false, array('AppApi\Write', 'deleteComment')),
		'comment.update' => array('POST', false, array('AppApi\Write', 'updateComment')),
		'document.vote' => array('POST', true, array('AppApi\Actions', 'vote')),
		'document.voters' => array('GET', false, array('AppApi\Actions', 'voters')),
		// 댓글 추천 (모듈 1.0.18~, 기능 comment_vote). 비회원 추천은 엔진이 설정대로 받거나 거절한다
		'comment.vote' => array('POST', false, array('AppApi\Actions', 'commentVote')),
		'document.scrap' => array('POST', true, array('AppApi\Actions', 'scrap')),
		'document.declare' => array('POST', true, array('AppApi\Actions', 'report')),
		// 비회원도 투표할 수 있다(웹과 같이 엔진이 IP 로 한 번만 받는다)
		'poll.vote' => array('POST', false, array('AppApi\Polls', 'vote')),
		'member.menu' => array('GET', false, array('AppApi\People', 'menu')),
		'member.info' => array('GET', true, array('AppApi\People', 'info')),
		'message.send' => array('POST', true, array('AppApi\People', 'sendMessage')),
		'friend.add' => array('POST', true, array('AppApi\People', 'addFriend')),
		'notify.count' => array('GET', true, array('AppApi\Notify', 'count')),
		'notify.list' => array('GET', true, array('AppApi\Notify', 'lists')),
		'notify.read' => array('POST', true, array('AppApi\Notify', 'read')),
		'notify.readall' => array('POST', true, array('AppApi\Notify', 'readAll')),
		'my.menu' => array('GET', true, array('AppApi\My', 'menu')),
		'my.documents' => array('GET', true, array('AppApi\My', 'documents')),
		'my.comments' => array('GET', true, array('AppApi\My', 'comments')),
		'my.scraps' => array('GET', true, array('AppApi\My', 'scraps')),
		'my.scrap.delete' => array('POST', true, array('AppApi\My', 'deleteScrap')),
		'my.logins' => array('GET', true, array('AppApi\My', 'logins')),
		'my.saved' => array('GET', true, array('AppApi\My', 'saved')),
		'my.saved.delete' => array('POST', true, array('AppApi\My', 'deleteSaved')),
		'my.messages' => array('GET', true, array('AppApi\My', 'messages')),
		'my.message' => array('GET', true, array('AppApi\My', 'message')),
		'my.message.delete' => array('POST', true, array('AppApi\My', 'deleteMessage')),
		'my.message.store' => array('POST', true, array('AppApi\My', 'storeMessage')),
		'my.friends' => array('GET', true, array('AppApi\My', 'friends')),
		'my.friend.delete' => array('POST', true, array('AppApi\My', 'deleteFriend')),
	);

	public static function run()
	{
		// 애드온·엔진이 화면을 찍고 exit 하면 JSON 오류로 바꾼다 (Response::onShutdown)
		register_shutdown_function(array('AppApi\Response', 'onShutdown'));
		try
		{
			$route = (isset($_GET['r']) && is_string($_GET['r'])) ? $_GET['r'] : '';
			if (!isset(self::$routes[$route]))
			{
				throw new ApiError(404, 'unknown_route', 'unknown route');
			}
			list($method, $auth, $handler) = self::$routes[$route];
			if (!in_array(strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'), explode('|', $method), true))
			{
				throw new ApiError(405, 'method_not_allowed', 'use ' . $method);
			}

			Core::boot();
			// 예전 판의 업데이트가 폴더째 남긴 백업(웹에서 옛 API 가 실행된다)을 zip 으로 (1.0.18~, 남은 것이 없으면 glob 한 번)
			$backups = rtrim(defined('RX_BASEDIR') ? RX_BASEDIR : \_XE_PATH_, '/') . '/files/appapi_backup';
			if (is_dir($backups) && glob($backups . '/*', GLOB_ONLYDIR))
			{
				require_once APPAPI_DIR . '/appapi.updater.php';
				\appapiUpdater::secureBackups();
			}
			if ($auth !== null)
			{
				Auth::authenticate($auth);
			}
			Response::ok(call_user_func($handler));
		}
		catch (ApiError $e)
		{
			Response::error($e->status, $e->error_code, $e->getMessage(), (array)$e->extra);
		}
		catch (\Throwable $e)
		{
			error_log('[appapi] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
			Response::error(500, 'server_error', 'server error');
		}
	}
}
