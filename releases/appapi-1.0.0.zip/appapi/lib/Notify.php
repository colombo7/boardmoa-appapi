<?php
namespace AppApi;

/**
 * 알림 (ncenterlite 알림 센터 모듈): 댓글·대댓글·이름 언급·추천 등. 웹 위쪽의 "N개의 알림이 있습니다"와 같은 것.
 *
 * 알림을 만드는 것은 엔진이 한다(앱에서 쓴 댓글·추천도 같은 엔진 동작이라 알림이 생긴다).
 * 글을 열면 그 글의 알림이 읽음이 되는 것도 엔진이 한다(글 보기 dispBoardContent 의 트리거, 설정 document_read).
 * 여기서는 목록·안 읽은 수·읽음 처리만 웹과 같은 모듈 함수로 한다. 목록은 DB 에서 바로 읽는다:
 * 웹 알림 막대는 회원별 캐시 파일을 먼저 보는데, 그 파일이 남으면 읽었는데도 막대가 계속 보일 수 있다.
 * 모듈이 없거나 알림을 쓰지 않는 사이트는 enabled=false (앱이 종 아이콘을 숨긴다).
 */
class Notify
{
	/** 안 읽은 알림 수 (앱 위쪽 종 아이콘) */
	public static function count()
	{
		if (!self::enabled())
		{
			return array('enabled' => false, 'unread' => 0);
		}
		return array('enabled' => true, 'unread' => self::unread());
	}

	/** 알림 목록 (안 읽은 것·읽은 것 모두, 최근 순으로 20개씩: 웹의 "알림 목록"과 같은 질의) */
	public static function lists()
	{
		self::requireEnabled();
		$oModel = getModel('ncenterlite');
		$args = new \stdClass;
		$args->member_srl = self::me();
		$args->page = max(1, Core::intParam('page', 1));
		$args->list_count = 20;
		$args->page_count = 10;
		$output = executeQueryArray('ncenterlite.getDispNotifyList', $args);
		$items = array();
		foreach ((array)$output->data as $row)
		{
			$image = !empty($row->target_member_srl) ? getModel('member')->getProfileImage($row->target_member_srl) : null;
			$items[] = array(
				'notify' => (string)$row->notify,
				'text' => trim(html_entity_decode(strip_tags((string)$oModel->getNotificationText($row)), ENT_QUOTES, 'UTF-8')),
				// 누르면 갈 곳: 앱이 글·댓글 화면으로 바꾼다 (본문 링크와 같은 처리)
				'url' => Core::absoluteUrl((string)$row->target_url),
				'regdate' => Core::isoTime((string)$row->regdate),
				'readed' => ($row->readed ?? 'N') === 'Y',
				'nick_name' => html_entity_decode((string)($row->target_nick_name ?? ''), ENT_QUOTES, 'UTF-8'),
				'profile_image' => $image ? Core::absoluteUrl($image->src) : null,
			);
		}
		return array(
			'notifications' => $items,
			'page' => max(1, (int)$output->page),
			'total_pages' => max(1, (int)$output->total_page),
			'unread' => self::unread(),
		);
	}

	/** 알림 하나 읽음 (웹에서 알림을 눌렀을 때와 같다: 자기 알림만) */
	public static function read()
	{
		self::requireEnabled();
		$notify = (string)Core::param('notify', '');
		if (!preg_match('/^[0-9a-zA-Z]{1,64}$/', $notify) || !getModel('ncenterlite')->getNotification($notify, self::me()))
		{
			throw new ApiError(404, 'notify_not_found', Auth::lang('msg_invalid_request'));
		}
		getController('ncenterlite')->updateNotifyRead($notify, self::me());
		return array('read' => true, 'unread' => self::unread());
	}

	/** 모두 읽음 */
	public static function readAll()
	{
		self::requireEnabled();
		getController('ncenterlite')->updateNotifyReadAll(self::me());
		return array('read' => true, 'unread' => 0);
	}

	// ---- 내부

	private static function enabled()
	{
		$oModel = getModel('ncenterlite');
		if (!$oModel || !method_exists($oModel, 'getConfig'))
		{
			return false;
		}
		$config = $oModel->getConfig();
		return !empty($config->use);
	}

	/**
	 * 안 읽은 수: 모듈의 같은 질의(getNotifyNewCount)를 캐시 없이. 모듈의 _getNewCount 는 캐시(Rhymix 객체 캐시·회원별 파일)를
	 * 먼저 보는데, 캐시가 DB 와 어긋나면 읽었는데도 수가 남거나 새 알림이 안 보일 수 있다.
	 */
	private static function unread()
	{
		$args = new \stdClass;
		$args->member_srl = self::me();
		$output = executeQuery('ncenterlite.getNotifyNewCount', $args);
		return $output->data ? (int)$output->data->cnt : 0;
	}

	private static function requireEnabled()
	{
		if (!self::enabled())
		{
			throw new ApiError(403, 'feature_disabled', Auth::lang('msg_not_permitted'));
		}
	}

	private static function me()
	{
		return (int)\Context::get('logged_info')->member_srl;
	}
}
