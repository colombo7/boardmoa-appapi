<?php
namespace AppApi;

/**
 * 게시판 추가 항목(확장 변수, extra_keys): 글쓰기·글 고치기 화면에 그릴 정의와 앱이 보낸 값.
 *
 * 앱은 회원 정보의 가입 항목(me.form)과 같은 꼴로 받고 보낸다: 값은 글자 하나(checkbox 는 "가, 나", kr_zip 은 칸마다 줄,
 * date 는 YYYY-MM-DD). 여기서 엔진이 웹 글쓰기 화면에서 받는 꼴(extra_vars{idx}, 여러 칸은 배열)로 바꿔 넘기고,
 * 필수·보기 확인·저장은 엔진이 웹과 같이 한다. 앱이 그릴 수 없는 형식(파일·국제 전화·국가 등)은 editable=false 로 알린다.
 */
class ExtraVars
{
	/** 엔진 형식 → 앱이 그리는 형식 (없는 형식은 앱에서 입력할 수 없다) */
	private static $appTypes = array(
		'text' => 'text', 'password' => 'text', 'textarea' => 'textarea', 'number' => 'number',
		'email_address' => 'email_address', 'email' => 'email_address', 'homepage' => 'url', 'url' => 'url',
		'tel' => 'tel', 'tel_v2' => 'tel', 'select' => 'select', 'radio' => 'radio', 'checkbox' => 'checkbox',
		'date' => 'date', 'time' => 'time', 'kr_zip' => 'kr_zip',
	);

	/** 우편번호 주소 칸 (krzip 모듈의 입력 칸 순서). 예전 값이 4칸이면 지번 주소가 없다 */
	private static $zipParts = array('우편번호', '주소', '지번 주소', '상세 주소', '참고 항목');

	/** 엔진의 정의 (idx 순서) */
	private static function definitions($module_srl)
	{
		static $cache = array();
		if (!isset($cache[$module_srl]))
		{
			$cache[$module_srl] = array();
			foreach ((array)getModel('document')->getExtraKeys($module_srl) as $key)
			{
				if (isset($key->idx) && (int)$key->idx > 0)
				{
					$cache[$module_srl][(int)$key->idx] = $key;
				}
			}
		}
		return $cache[$module_srl];
	}

	/**
	 * board.extra_keys: [{idx, name, type, engine_type, required, options, parts, default, desc, editable}]
	 */
	public static function keys($module_srl)
	{
		$result = array();
		foreach (self::definitions($module_srl) as $idx => $key)
		{
			$type = (string)$key->type;
			$app_type = self::$appTypes[$type] ?? null;
			$editable = $app_type !== null && ($key->is_disabled ?? 'N') !== 'Y' && ($key->is_readonly ?? 'N') !== 'Y';
			$default = self::options($key) ? '' : (is_array($key->default) ? '' : trim((string)$key->default));
			$result[] = array(
				'idx' => $idx,
				'name' => self::text($key->name),
				'type' => $app_type ?: $type,
				'engine_type' => $type,
				'required' => ($key->is_required ?? 'N') === 'Y',
				'options' => self::options($key),
				'parts' => $type === 'kr_zip' ? self::$zipParts : array(),
				'default' => $type === 'date' ? self::date($default) : $default,
				'desc' => trim(strip_tags(self::text($key->desc ?? ''))),
				'editable' => $editable,
			);
		}
		return $result;
	}

	/**
	 * document.source.extra_values: {idx: 앱 꼴의 값} (지금 저장된 값)
	 */
	public static function values($oDocument)
	{
		$keys = self::definitions((int)$oDocument->get('module_srl'));
		$result = new \stdClass;
		foreach ((array)$oDocument->getExtraVars() as $extra)
		{
			$idx = isset($extra->idx) ? (int)$extra->idx : 0;
			if (!$idx || !isset($keys[$idx]))
			{
				continue;
			}
			$result->{$idx} = self::toApp((string)$keys[$idx]->type, $extra->value);
		}
		return $result;
	}

	/**
	 * 앱이 보낸 값(extra_vars: {idx: 값}, JSON 객체 또는 그 글자)을 엔진 요청 값 extra_vars{idx} 로 $vars 에 넣는다.
	 * 앱에서 입력할 수 있는 항목만, 보낸 것만 바꾼다(글 고치기에서 나머지는 원래 값 그대로).
	 */
	public static function apply(array &$vars, $module_srl)
	{
		$input = Core::param('extra_vars');
		if (is_string($input))
		{
			$input = json_decode($input, true);
		}
		if (!is_array($input) || !$input)
		{
			return;
		}
		foreach (self::definitions($module_srl) as $idx => $key)
		{
			$type = (string)$key->type;
			if (!array_key_exists((string)$idx, $input) || !isset(self::$appTypes[$type]) || ($key->is_disabled ?? 'N') === 'Y' || ($key->is_readonly ?? 'N') === 'Y')
			{
				continue;
			}
			$raw = $input[(string)$idx];
			$value = trim(is_array($raw) ? implode(', ', array_map('strval', $raw)) : (string)$raw);
			$value = mb_substr($value, 0, 5000);
			switch ($type)
			{
				case 'date':
					$value = preg_replace('/[^0-9]/', '', $value);
					break;
				case 'tel':
					$value = $value === '' ? array('', '', '') : array_pad(array_slice(preg_split('/[-\s]+/', $value), 0, 3), 3, '');
					break;
				case 'tel_v2':
					$value = array($value);
					break;
				case 'kr_zip':
					$lines = array_map('trim', explode("\n", str_replace("\r", '', is_array($raw) ? implode("\n", $raw) : (string)$raw)));
					$value = implode('', $lines) === '' ? '' : array_pad(array_slice($lines, 0, 5), max(4, min(5, count($lines))), '');
					break;
				case 'checkbox':
					$value = array_values(array_filter(array_map('trim', explode(',', $value)), 'strlen'));
					break;
				case 'select':
				case 'radio':
					$options = self::options($key);
					if ($value !== '' && $options && !in_array($value, $options, true))
					{
						throw new ApiError(400, 'invalid_field', self::text($key->name));
					}
					break;
			}
			$vars['extra_vars' . $idx] = $value;
		}
	}

	/** 보기 목록: Rhymix 는 getOptions(), XE 는 기본값을 쉼표·|@| 로 나눈 것 */
	private static function options($key)
	{
		if (!in_array((string)$key->type, array('select', 'radio', 'checkbox'), true))
		{
			return array();
		}
		if (method_exists($key, 'getOptions'))
		{
			$options = $key->getOptions();
		}
		else
		{
			$default = $key->default;
			$options = is_array($default) ? $default : preg_split('/\|@\||,/', (string)$default);
		}
		return array_values(array_filter(array_map(function ($v) { return trim((string)$v); }, (array)$options), 'strlen'));
	}

	/** 저장된 값을 앱 꼴의 글자로 (회원 가입 항목 me.form 과 같은 꼴) */
	private static function toApp($type, $value)
	{
		if (is_string($value) && strpos($value, '|@|') !== false)
		{
			$value = explode('|@|', $value);
		}
		elseif (is_string($value) && preg_match('/^\[.*\]$/s', $value) && is_array(json_decode($value, true)))
		{
			$value = json_decode($value, true);
		}
		$list = array_map(function ($v) { return trim((string)$v); }, is_array($value) ? array_values($value) : array((string)$value));
		switch ($type)
		{
			case 'date':
				return self::date($list[0] ?? '');
			case 'tel':
			case 'tel_v2':
				return implode('-', array_filter($list, 'strlen'));
			case 'checkbox':
				return implode(', ', array_filter($list, 'strlen'));
			case 'kr_zip':
				return implode('' , $list) === '' ? '' : implode("\n", array_pad(array_slice($list, 0, 5), 5, ''));
			case 'select':
			case 'radio':
				return $list[0] ?? '';
			default:
				return implode(' ', $list);
		}
	}

	private static function date($value)
	{
		return preg_match('/^(\d{4})(\d{2})(\d{2})/', (string)$value, $m) ? $m[1] . '-' . $m[2] . '-' . $m[3] : (string)$value;
	}

	/** 관리자가 다국어 값($user_lang->…)으로 넣은 이름 */
	private static function text($text)
	{
		$text = (string)$text;
		return method_exists('Context', 'replaceUserLang') ? (string)\Context::replaceUserLang($text) : $text;
	}
}
