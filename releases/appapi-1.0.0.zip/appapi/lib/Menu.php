<?php
namespace AppApi;

/**
 * 사이트 정보와 메뉴.
 *
 * 메뉴는 시작 모듈의 PC 레이아웃에 연결된 메뉴 캐시(files/cache/menu/<srl>.php)를 읽는다.
 * 캐시 파일이 Context 의 logged_info 로 그룹별 표시 여부를 계산하므로, 로그인 상태를 만든 뒤 읽어야 한다.
 */
class Menu
{
	public static function site()
	{
		$index = self::indexModule();
		return array(
			'name' => Core::userLang(Core::config('site_name') ?: ($index ? $index->browser_title : $_SERVER['HTTP_HOST'])),
			'base_url' => Core::$base_url,
			'theme_color' => Core::config('theme_color') ?: null,
			'logo_url' => self::logoUrl($index),
			'icon_url' => self::iconUrl(),
			'home_mid' => $index ? $index->mid : null,
			'engine' => Core::$engine,
			'engine_version' => defined('RX_VERSION') ? RX_VERSION : (defined('__XE_VERSION__') ? __XE_VERSION__ : null),
			'api_version' => APPAPI_VERSION,
			// 내용 언어 (모듈 0.10.19~): 앱이 보낸 X-App-Lang 을 사이트가 켜 두었으면 그 언어, 아니면 사이트 기본 언어
			'lang' => (string)\Context::getLangType(),
			// 이 모듈이 할 줄 아는 것 (앱은 여기 있을 때만 그 기능을 쓴다. 예전 모듈엔 없어서 예전 방식으로 동작)
			'features' => self::features(),
			'member' => Auth::profile(),
		);
	}

	/**
	 * 모듈이 지원하는 기능 이름 (docs/API.md '기능 목록').
	 * html_write: 새 글을 꾸밈 HTML 로 받는다(document.write content_format=html)
	 * polls: 글 속 투표를 데이터로 주고(document.polls) 투표를 받는다(poll.vote)
	 * extra_vars: 게시판 추가 항목 정의(board.extra_keys)를 주고 글쓰기·고치기에서 값(extra_vars)을 받는다
	 * media_html: document 에 with_media=1 을 주면 멀티미디어·이미지 갤러리 부품을 보통 HTML 로 바꾼다
	 * captcha_solve: CAPTCHA 위젯 정보(board.captcha_widget·signup.form captcha_widget·error.captcha)를 주고,
	 *   앱이 푼 답(captcha_response)을 엔진의 CAPTCHA 확인에 넘긴다. 앱 로그인도 로그인 CAPTCHA 를 확인한다
	 * guest_write: 비회원도 글쓰기 권한이 있으면 document.write 를 받는다(board.guest_fields 의 이름·비밀번호), 사진 첨부도 웹과 같은 판단
	 * edit_photos: document.update 가 새 사진(multipart photos[])을 받아 그 글에 첨부로 붙이고 본문 끝에 넣는다
	 * guest_manage: 비회원 글·댓글을 비밀번호로 고치고 지우며(password_edit), 비회원 비밀글을 비밀번호로 연다(password_view)
	 * guest_comment: 비회원도 댓글 권한이 있으면 comment.write 를 받는다(board.guest_comment_fields 의 이름·비밀번호)
	 * comment_edit: comment.update 로 댓글을 고친다(댓글의 can_edit)
	 */
	public static function features()
	{
		return array('html_write', 'polls', 'extra_vars', 'media_html', 'captcha_solve', 'guest_write', 'edit_photos', 'guest_manage', 'guest_comment', 'comment_edit');
	}

	/**
	 * 메뉴에 있는 게시판 mid 전부 (모아 보기 기본 대상).
	 */
	public static function boardMids()
	{
		$mids = array();
		$walk = function ($items) use (&$walk, &$mids) {
			foreach ($items as $item)
			{
				if ($item['module'] === 'board')
				{
					$mids[] = $item['mid'];
				}
				$walk($item['children']);
			}
		};
		foreach (self::menus()['menus'] as $menu)
		{
			$walk($menu['items']);
		}
		return array_values(array_unique($mids));
	}

	public static function menus()
	{
		$index = self::indexModule();
		$layout_srl = $index ? (int)$index->layout_srl : -1;
		if ($layout_srl <= 0)
		{
			$layout_srl = (int)getAdminModel('layout')->getSiteDefaultLayout('P');
		}
		$layout = $layout_srl > 0 ? getModel('layout')->getLayout($layout_srl) : null;

		$menus = array();
		if ($layout && !empty($layout->menu))
		{
			foreach ($layout->menu as $menu_id => $menu)
			{
				$menu_srl = (int)$menu->menu_srl;
				if ($menu_srl <= 0)
				{
					continue;
				}
				$items = self::loadMenuCache($menu_srl);
				if (!$items)
				{
					continue;
				}
				$menus[] = array(
					'id' => $menu_id,
					'title' => $menu->title ?? $menu_id,
					'items' => $items,
				);
			}
		}
		return array('menus' => $menus);
	}

	/**
	 * 사이트 로고: config.php 의 logo_url → 시작 모듈 레이아웃의 로고 이미지 변수(logo_image 등).
	 */
	private static function logoUrl($index)
	{
		if (Core::config('logo_url'))
		{
			return Core::absoluteUrl(Core::config('logo_url'));
		}
		$layout_srl = $index ? (int)$index->layout_srl : -1;
		if ($layout_srl <= 0)
		{
			$layout_srl = (int)getAdminModel('layout')->getSiteDefaultLayout('P');
		}
		$layout = $layout_srl > 0 ? getModel('layout')->getLayout($layout_srl) : null;
		if (!$layout || empty($layout->extra_var))
		{
			return null;
		}
		$candidates = array();
		foreach ($layout->extra_var as $name => $var)
		{
			if (($var->type ?? '') === 'image' && stripos($name, 'logo') !== false && !empty($var->value))
			{
				$candidates[$name] = $var->value;
			}
		}
		if (!$candidates)
		{
			return null;
		}
		$value = $candidates['logo_image'] ?? reset($candidates);
		return Core::absoluteUrl($value);
	}

	/**
	 * 사이트 아이콘(정사각형): config.php 의 icon_url → 모바일 홈 아이콘 → 파비콘.
	 */
	private static function iconUrl()
	{
		if (Core::config('icon_url'))
		{
			return Core::absoluteUrl(Core::config('icon_url'));
		}
		foreach (array('files/attach/xeicon/mobicon.png', 'files/attach/xeicon/favicon.ico') as $file)
		{
			if (file_exists('./' . $file))
			{
				return Core::$base_url . $file;
			}
		}
		return null;
	}

	private static function indexModule()
	{
		$site = \Context::get('site_module_info');
		if (!$site)
		{
			return null;
		}
		// Rhymix: 도메인 정보에 index_module_srl / 구 XE: 시작 모듈 정보 자체
		$module_srl = isset($site->index_module_srl) ? (int)$site->index_module_srl : (int)$site->module_srl;
		return $module_srl ? getModel('module')->getModuleInfoByModuleSrl($module_srl) : null;
	}

	private static function loadMenuCache($menu_srl)
	{
		$file = './files/cache/menu/' . $menu_srl . '.php';
		if (!file_exists($file))
		{
			getAdminController('menu')->makeXmlFile($menu_srl);
		}
		if (!file_exists($file))
		{
			return array();
		}
		$menu = null;
		include $file;
		return ($menu && !empty($menu->list)) ? self::convertItems($menu->list) : array();
	}

	/**
	 * 같은 사이트 주소(/mid, ?mid=..)에서 mid 를 뽑는다. 다른 사이트면 null.
	 */
	private static function internalMid($url)
	{
		$parts = parse_url(Core::absoluteUrl($url));
		$site_host = preg_replace('/^www\./', '', strtolower(parse_url(Core::$base_url, PHP_URL_HOST)));
		if (empty($parts['host']) || preg_replace('/^www\./', '', strtolower($parts['host'])) !== $site_host)
		{
			return null;
		}
		if (!empty($parts['query']))
		{
			parse_str($parts['query'], $query);
			if (!empty($query['mid']) && is_string($query['mid']))
			{
				return $query['mid'];
			}
		}
		if (!empty($parts['path']) && preg_match('#^/([a-zA-Z][a-zA-Z0-9_]*)/?$#', $parts['path'], $m))
		{
			return $m[1];
		}
		return null;
	}

	private static function convertItems($list)
	{
		$items = array();
		foreach ((array)$list as $node)
		{
			if (empty($node['isShow']) || (string)$node['text'] === '')
			{
				continue;
			}
			$url = (string)$node['url'];
			$is_mid = $url !== '' && $node['is_shortcut'] !== 'Y' && preg_match('/^[a-zA-Z][a-zA-Z0-9_]*$/', $url);
			$children = self::convertItems($node['list'] ?? array());
			$had_children = !empty($node['list']);
			$module = null;
			$grant = null;
			// 바로가기 링크가 같은 사이트의 게시판을 가리키면 그 게시판 권한으로 거른다
			if (!$is_mid && $url !== '' && ($linked = self::internalMid($url)) !== null)
			{
				$linked_info = getModel('module')->getModuleInfoByMid($linked);
				if ($linked_info && !Board::isVisible($linked_info) && !$children)
				{
					continue;
				}
			}
			// 링크 없는 묶음 제목('#' 바로가기)인데 하위가 모두 권한 밖이면 빈 묶음만 남으므로 뺀다
			if (!$is_mid && $had_children && !$children && ($url === '' || $url[0] === '#'))
			{
				continue;
			}
			if ($is_mid)
			{
				$module_info = getModel('module')->getModuleInfoByMid($url);
				if (!$module_info || !Board::isVisible($module_info))
				{
					// 권한이 없는 게시판·페이지는 빼고, 하위에 볼 수 있는 항목이 있으면 묶음 제목으로만 남긴다
					if (!$children)
					{
						continue;
					}
					$is_mid = false;
					$url = '';
				}
				elseif ($module_info->module === 'page' && $had_children && !$children)
				{
					// 하위 게시판 묶음의 대표 페이지인데 하위가 모두 권한 밖이면 숨긴다.
					// 이런 페이지는 보통 하위 게시판의 최신글 위젯을 보여 주므로, 권한 없는 글 제목이 드러난다.
					continue;
				}
				else
				{
					$module = $module_info->module;
					if ($module === 'board')
					{
						$g = Board::grant($module_info);
						$grant = array(
							'view' => (bool)$g->view,
							'write_document' => (bool)$g->write_document,
							'write_comment' => (bool)$g->write_comment,
						);
					}
				}
			}
			$items[] = array(
				'title' => html_entity_decode(strip_tags(Core::userLang((string)$node['text'])), ENT_QUOTES, 'UTF-8'),
				'mid' => $is_mid ? $url : null,
				'module' => $module,
				'grant' => $grant,
				'url' => $is_mid ? Core::$base_url . $url : ($url !== '' ? Core::absoluteUrl($url) : null),
				'open_window' => $node['open_window'] === 'Y',
				'children' => $children,
			);
		}
		return $items;
	}
}
