<?php
namespace AppApi;

/**
 * 내 정보 수정 (닉네임·이메일·프로필 사진·비밀번호).
 *
 * 웹의 회원정보 수정과 같은 엔진 함수(procMemberModifyInfo 등)를 실행하므로 닉네임 중복, 금지어,
 * 닉네임·이메일 변경 허용 여부 같은 사이트 규칙이 그대로 적용된다.
 * 엔진 함수는 요청에 없는 가입 항목을 빈 값으로 저장하므로, 지금 값을 모두 채운 뒤 바꾼 항목만 덮어쓴다.
 */
class Member
{
	/** 앱 수정 화면에 필요한 값 */
	public static function form()
	{
		$info = self::loggedInfo();
		$config = getModel('member')->getMemberConfig();
		$image = getModel('member')->getProfileImage($info->member_srl);
		$fields = self::fields($info->member_srl);
		$locked = array_filter($fields, function ($f) { return $f['name'] === 'signature' && !$f['editable']; });
		return array(
			'nick_name' => $info->nick_name,
			'email_address' => $info->email_address,
			'profile_image' => $image ? Core::absoluteUrl($image->src) : null,
			'can_change_nickname' => self::canChange('nick_name', $config),
			// 닉네임 안내 (1.0.23~, 새 필드): 사이트가 닉네임 변경을 막았을 때
			'nickname_notice' => self::canChange('nick_name', $config) ? null : \appapiText::t('이 사이트는 닉네임을 바꿀 수 없습니다.'),
			'can_change_email' => self::canChange('email_address', $config),
			'profile_image_enabled' => self::profileImageEnabled($config),
			'profile_image_max_width' => (int)($config->profile_image_max_width ?? 90) ?: 90,
			'profile_image_max_height' => (int)($config->profile_image_max_height ?? 90) ?: 90,
			'fields' => $fields,
			// 프로필 사진 말고 웹 회원정보 수정에서 바꾸는 회원 그림 (1.0.21~, 새 필드): 이미지 이름·이미지 마크
			'images' => self::images($info->member_srl, $config),
			// 꾸밈(글꼴·사진·링크)이 든 서명은 앱에서 잠근다: 웹에서 고치도록 안내
			'web_notice' => $locked ? \appapiText::t('꾸밈이 있는 서명은 웹사이트의 회원정보 수정에서 바꿀 수 있습니다.') : null,
			'web_url' => getNotEncodedFullUrl('', 'act', 'dispMemberModifyInfo'),
		);
	}

	/** 그 가입 항목을 쓰는가 (회원 설정 > 가입 양식에서 켬: 웹 회원정보 수정 화면에 그 칸이 나온다) */
	private static function formUses($config, $name)
	{
		foreach ((array)$config->signupForm as $form)
		{
			if ($form->name === $name)
			{
				return !empty($form->isUse) ? $form : null;
			}
		}
		return null;
	}

	/** 이미지 이름·이미지 마크: 웹 회원정보 수정과 같이 가입 양식에서 켠 것만 */
	private static function images($member_srl, $config)
	{
		$out = array();
		$oModel = getModel('member');
		foreach (array('image_name' => 'getImageName', 'image_mark' => 'getImageMark') as $kind => $getter)
		{
			$form = self::formUses($config, $kind);
			if (!$form)
			{
				continue;
			}
			$image = $oModel->$getter($member_srl);
			$out[] = array(
				'kind' => $kind,
				'title' => self::title($form),
				'url' => ($image && !empty($image->src)) ? Core::absoluteUrl($image->src) : null,
				'max_width' => (int)($config->{$kind . '_max_width'} ?? 0) ?: ($kind === 'image_name' ? 90 : 20),
				'max_height' => (int)($config->{$kind . '_max_height'} ?? 0) ?: 20,
			);
		}
		return $out;
	}

	/** 서명 (가입 양식에서 켰을 때): 글자만 있는 서명은 앱에서 고친다. 글꼴·사진·링크가 든 서명은 웹에서 (앱은 글자 칸이라 꾸밈이 사라진다) */
	private static function signatureField($member_srl, $config)
	{
		$form = self::formUses($config, 'signature');
		if (!$form)
		{
			return null;
		}
		$html = (string)getModel('member')->getSignature($member_srl);
		$plain = trim(preg_replace('#<br\s*/?>|</p>\s*<p>#i', "\n", preg_replace('#^\s*<p>|</p>\s*$#i', '', trim($html))));
		$editable = !preg_match('/<[a-z!\/]/i', $plain);
		return array(
			'name' => 'signature', 'title' => self::title($form), 'type' => 'textarea', 'required' => !empty($form->required),
			'value' => $editable ? html_entity_decode($plain, ENT_QUOTES, 'UTF-8') : self::plainText($html),
			'options' => array(), 'parts' => array(), 'editable' => $editable,
		);
	}

	/** 앱이 보낸 서명 글자를 엔진이 저장하는 꼴로 (Rhymix 에서 서명에 HTML 을 쓰지 않으면 엔진이 글자로 바꾼다) */
	private static function signatureHtml($text)
	{
		$config = getModel('member')->getMemberConfig();
		$text = str_replace(array("\r\n", "\r"), "\n", trim($text));
		if (Core::$engine === 'rhymix' && isset($config->signature_html) && $config->signature_html === 'N')
		{
			return $text;
		}
		return $text === '' ? '' : '<p>' . nl2br(htmlspecialchars($text, ENT_QUOTES, 'UTF-8'), false) . '</p>';
	}

	/** 닉네임·이메일·아이디·사진 말고 사이트가 쓰는 가입 항목들 (생일, 연락처, 추가 항목 등) */
	private static function fields($member_srl)
	{
		$row = self::memberRow($member_srl);
		$extra = self::extraVars($row);
		$config = getModel('member')->getMemberConfig();
		$join = array();
		foreach ((array)getModel('member')->getJoinFormList() as $item)
		{
			$join[strtolower($item->column_name)] = $item;
		}
		$result = array();
		foreach ((array)$config->signupForm as $form)
		{
			if (empty($form->isUse) || in_array($form->name, self::$fixed, true))
			{
				continue;
			}
			$required = !empty($form->required) || !empty($form->mustRequired);
			if (!empty($form->isDefaultForm))
			{
				$type = array('birthday' => 'date', 'homepage' => 'url', 'blog' => 'url', 'phone_number' => 'tel')[$form->name] ?? 'text';
				$value = (string)($row[$form->name] ?? '');
				if ($type === 'date' && preg_match('/^(\d{4})(\d{2})(\d{2})/', $value, $m))
				{
					$value = $m[1] . '-' . $m[2] . '-' . $m[3];
				}
				$result[] = array('name' => $form->name, 'title' => self::title($form), 'type' => $type, 'required' => $required, 'value' => $value, 'options' => array(), 'parts' => array(), 'editable' => true);
				continue;
			}
			$item = $join[$form->name] ?? null;
			$type = $item ? $item->column_type : ($form->type ?? 'text');
			$raw = $extra[$form->name] ?? '';
			// 보기 목록: Rhymix 는 options, XE 는 default_value 에 담는다
			$options = array();
			if ($item && isset($item->options) && is_array($item->options))
			{
				$options = $item->options;
			}
			elseif ($item && is_array($item->default_value))
			{
				$options = $item->default_value;
			}
			$options = array_values(array_map('strval', $options));
			$parts = array();
			if ($type === 'kr_zip')
			{
				// 칸마다 줄로 나눠 보낸다. Rhymix 는 5칸(지번 주소 포함), XE 는 4칸
				$list = array_map('strval', is_array($raw) ? array_values($raw) : array((string)$raw));
				$parts = count($list) >= 5 ? array('우편번호', '주소', '지번 주소', '상세 주소', '참고 항목') : array('우편번호', '주소', '상세 주소', '참고 항목');
				$value = implode("\n", array_pad(array_slice($list, 0, count($parts)), count($parts), ''));
			}
			elseif ($type === 'date' && preg_match('/^(\d{4})(\d{2})(\d{2})$/', is_array($raw) ? '' : (string)$raw, $m))
			{
				$value = $m[1] . '-' . $m[2] . '-' . $m[3];
			}
			elseif ($type === 'tel')
			{
				$value = is_array($raw) ? implode('-', array_filter(array_map('trim', $raw), 'strlen')) : (string)$raw;
			}
			elseif ($type === 'checkbox')
			{
				$value = is_array($raw) ? implode(', ', $raw) : (string)$raw;
			}
			else
			{
				$value = is_array($raw) ? implode(' ', array_filter(array_map('trim', $raw), 'strlen')) : (string)$raw;
			}
			$result[] = array(
				'name' => $form->name, 'title' => self::title($form), 'type' => $type, 'required' => $required,
				'value' => $value, 'options' => $options, 'parts' => $parts,
				// 우편번호 주소처럼 여러 칸이 엮인 형식은 앱에서 고치지 않는다 (웹에서)
				'editable' => in_array($type, self::$editableTypes, true),
			);
		}
		// 서명은 웹 회원정보 수정의 맨 끝 (1.0.21~)
		if ($signature = self::signatureField($member_srl, $config))
		{
			$result[] = $signature;
		}
		return $result;
	}

	/** 앱에서 직접 고칠 수 있는 추가 항목 형식 */
	private static $editableTypes = array('text', 'textarea', 'email_address', 'homepage', 'tel', 'select', 'radio', 'checkbox', 'date', 'kr_zip');

	/** 별도 칸이나 다른 화면에서 다루는 항목 */
	private static $fixed = array('user_id', 'email_address', 'nick_name', 'password', 'profile_image', 'image_name', 'image_mark', 'signature', 'find_account_question', 'find_account_answer');

	/**
	 * 회원이 바꿀 수 있는 항목인가. 웹의 회원정보 수정 화면과 같은 기준:
	 * 로그인 식별자(아이디 또는 이메일)는 읽기 전용, 닉네임 변경 금지 설정, 이메일 인증을 쓰는 사이트의 이메일(Rhymix).
	 */
	private static function canChange($name, $config)
	{
		if ($name === 'user_id' || $name === self::identifier($config))
		{
			return false;
		}
		if ($name === 'nick_name')
		{
			return !(isset($config->allow_nickname_change) && $config->allow_nickname_change === 'N');
		}
		if ($name === 'email_address')
		{
			return !(Core::$engine === 'rhymix' && isset($config->enable_confirm) && $config->enable_confirm === 'Y');
		}
		return true;
	}

	/** 로그인 식별자로 쓰는 항목 (엔진의 회원정보 수정 화면 기준) */
	private static function identifier($config)
	{
		if (Core::$engine === 'rhymix')
		{
			$identifiers = isset($config->identifiers) ? (array)$config->identifiers : array('user_id', 'email_address');
			return reset($identifiers) === 'email_address' ? 'email_address' : 'user_id';
		}
		return !empty($config->identifier) ? $config->identifier : 'user_id';
	}

	private static function title($form)
	{
		$title = isset($form->title) ? (string)$form->title : '';
		return $title !== '' ? $title : Auth::lang($form->name);
	}

	private static function extraVars($row)
	{
		$extra = ($row && $row['extra_vars']) ? @unserialize($row['extra_vars'], array('allowed_classes' => array('stdClass'))) : null;
		return is_object($extra) ? get_object_vars($extra) : (is_array($extra) ? $extra : array());
	}

	/**
	 * 앱 회원가입 양식: 웹 가입 화면과 같은 설정(가입 허용·약관·가입 항목·비밀번호 규칙·메일 인증).
	 */
	public static function signupForm()
	{
		$config = getModel('member')->getMemberConfig();
		$enabled = ($config->enable_join ?? 'N') === 'Y';
		$result = array('enabled' => $enabled, 'web_url' => getFullUrl('', 'act', 'dispMemberSignUpForm'));
		if (!$enabled)
		{
			return $result;
		}
		// 가입에 스팸 방지 CAPTCHA 를 쓰는 사이트: 0.10.14 앱은 web_only 를 보고 웹으로 보낸다.
		// 더 새 앱은 captcha_widget(0.10.15~)이 있으면 앱에서 풀고 가입한다 (없으면 앱이 모르는 종류라 웹으로)
		if (Board::captchaRequired('signup'))
		{
			$result['captcha'] = true;
			$result['web_only'] = true;
			$result['captcha_widget'] = Board::captchaWidget();
		}
		$basic = array();
		$form = array();
		foreach ((array)$config->signupForm as $item)
		{
			$form[$item->name] = $item;
		}
		// 이름(user_name)은 가입 항목 목록(fields)에 들어 있다
		foreach (array('user_id', 'email_address', 'nick_name') as $name)
		{
			$item = $form[$name] ?? null;
			if ($name !== 'email_address' && (!$item || empty($item->isUse)))
			{
				continue;
			}
			$basic[] = array('name' => $name, 'title' => $item ? self::title($item) : Auth::lang($name),
				'required' => $name === 'email_address' || $name === 'user_id' || !empty($item->required) || !empty($item->mustRequired));
		}
		$agreements = array();
		if (Core::$engine === 'rhymix')
		{
			foreach ((array)($config->agreements ?? array()) as $i => $agreement)
			{
				if (($agreement->type ?? '') === 'disabled')
				{
					continue;
				}
				$agreements[] = array('index' => (int)$i, 'title' => (string)($agreement->title ?? \appapiText::t('약관')),
					'content' => self::plainText((string)($agreement->content ?? '')), 'required' => ($agreement->type ?? '') === 'required');
			}
		}
		elseif (!empty($config->agreement))
		{
			$agreements[] = array('index' => 0, 'title' => \appapiText::t('이용약관'), 'content' => self::plainText((string)$config->agreement), 'required' => true);
		}
		$strength = (string)($config->password_strength ?? 'normal');
		$hints = Auth::lang('about_password_strength');
		$result += array(
			'basic' => $basic,
			'agreements' => $agreements,
			'password_hint' => (is_array($hints) && !empty($hints[$strength])) ? strip_tags((string)$hints[$strength]) : \appapiText::t('비밀번호는 4자 이상으로 정해 주세요.'),
			'needs_confirm' => ($config->enable_confirm ?? 'N') === 'Y',
			'fields' => self::fields(0),
		);
		return $result;
	}

	/**
	 * 앱 회원가입: 웹과 같은 엔진 가입(procMemberInsert)으로. 약관·필수 항목·중복·비밀번호 강도·가입 승인·스팸 방지는 엔진이 판단한다.
	 * 메일 인증을 쓰지 않으면 바로 앱 로그인 토큰을 준다.
	 */
	public static function signup()
	{
		try
		{
			return self::signupInner();
		}
		catch (ApiError $e)
		{
			throw $e;
		}
		catch (\Throwable $t)
		{
			// 엔진 내부 오류 문구(SQL·경로)는 앱에 보내지 않는다
			error_log('[appapi] signup: ' . get_class($t) . ': ' . $t->getMessage());
			throw new ApiError(500, 'signup_error', \appapiText::t('가입을 처리하지 못했습니다. 잠시 뒤에 다시 해 주세요.'));
		}
	}

	private static function signupInner()
	{
		$config = getModel('member')->getMemberConfig();
		if (($config->enable_join ?? 'N') !== 'Y')
		{
			throw new ApiError(403, 'signup_disabled', Auth::lang('msg_signup_disabled'));
		}
		$password = Core::str('password');
		$vars = array('module' => 'member', 'password' => $password, 'password1' => $password, 'password2' => $password);
		foreach (array('user_id', 'email_address', 'nick_name', 'user_name') as $name)
		{
			$value = trim(Core::str($name));
			if ($value !== '')
			{
				$vars[$name] = mb_substr($value, 0, 80);
			}
		}
		// 약관: 동의한 약관 번호 목록
		$accepted = array_map('intval', (array)Core::param('agreements'));
		if (Core::$engine === 'rhymix')
		{
			$accept = array();
			foreach ((array)($config->agreements ?? array()) as $i => $agreement)
			{
				$accept[$i] = in_array((int)$i, $accepted, true) ? 'Y' : 'N';
			}
			$vars['accept_agreement'] = $accept;
		}
		else
		{
			$vars['accept_agreement'] = in_array(0, $accepted, true) ? 'Y' : 'N';
		}
		self::applyFields($vars, Core::param('fields'), 0);
		if (Core::$engine === 'xe')
		{
			// XE 는 요청 값 전체를 추가 정보로 저장하므로 API 자체의 값(r 등)이 섞이지 않게 비운다
			\Context::getInstance()->get_vars = new \stdClass;
		}
		Board::$allowGuestWrite = true;
		try
		{
			Board::run('', 'procMemberInsert', $vars, false);
		}
		catch (ApiError $e)
		{
			// CAPTCHA 답을 보낸 새 앱에는 captcha_required 그대로 (다시 풀게). 예전 앱은 예전처럼 signup_failed
			if ($e->error_code === 'captcha_required' && Board::captchaResponse() !== '')
			{
				throw $e;
			}
			throw new ApiError(400, 'signup_failed', $e->getMessage());
		}
		catch (\Throwable $t)
		{
			// 엔진 내부 오류 문구(SQL·경로)는 앱에 보내지 않는다
			error_log('[appapi] signup: ' . get_class($t) . ': ' . $t->getMessage());
			throw new ApiError(500, 'signup_error', \appapiText::t('가입을 처리하지 못했습니다. 잠시 뒤에 다시 해 주세요.'));
		}
		finally
		{
			Board::$allowGuestWrite = false;
		}
		if (($config->enable_confirm ?? 'N') === 'Y')
		{
			return array('needs_confirm' => true);
		}
		// 엔진이 가입을 마치며 이미 로그인시켰다(웹과 같다). 다시 로그인하면 로그인 기록 모듈이 같은 클래스를 두 번 불러 PHP 가 멈추므로
		// 엔진이 로그인시킨 회원으로 앱 토큰만 준다. 로그인되지 않았으면(가입 승인 대기 등) 가입만 알린다.
		$info = \Context::get('logged_info');
		$row = ($info && !empty($info->member_srl)) ? self::memberRow($info->member_srl) : null;
		if (!$row || (string)$row['user_id'] !== (string)($vars['user_id'] ?? $row['user_id']))
		{
			return array('needs_confirm' => false, 'logged_in' => false);
		}
		$tokens = Tokens::issue($row['member_srl'], $row['password'], Core::str('device_name'), Core::str('platform'));
		return array('needs_confirm' => false, 'logged_in' => true, 'tokens' => $tokens, 'member' => Auth::profile());
	}

	private static function plainText($html)
	{
		$text = preg_replace('#<br\s*/?>|</p>|</div>|</li>#i', "\n", $html);
		$text = html_entity_decode(strip_tags($text), ENT_QUOTES, 'UTF-8');
		return trim(preg_replace("/\n{3,}/", "\n\n", $text));
	}

	/** 앱이 보낸 가입 항목 값을 엔진이 받는 꼴로 */
	private static function applyFields(array &$vars, $fields, $member_srl)
	{
		if (!is_array($fields))
		{
			return;
		}
		foreach (self::fields($member_srl) as $field)
		{
			$name = $field['name'];
			if (!$field['editable'] || !array_key_exists($name, $fields))
			{
				continue;
			}
			// 배열로 온 값은 글자로 이어 받는다 (그대로 (string) 하면 "Array" 가 저장된다). 그 밖의 꼴은 빈 값
			$raw = $fields[$name];
			if (is_array($raw))
			{
				$raw = implode($field['type'] === 'kr_zip' ? "\n" : ',', array_filter($raw, 'is_scalar'));
			}
			elseif (!is_scalar($raw))
			{
				$raw = '';
			}
			$value = trim((string)$raw);
			if ($field['type'] === 'date')
			{
				$value = preg_replace('/[^0-9]/', '', $value);
			}
			elseif ($field['type'] === 'tel')
			{
				$value = $value === '' ? array('', '', '') : array_pad(array_slice(preg_split('/[-\s]+/', $value), 0, 3), 3, '');
			}
			elseif ($field['type'] === 'kr_zip')
			{
				$count = max(4, count($field['parts']));
				$value = array_pad(array_slice(array_map('trim', explode("\n", (string)$raw)), 0, $count), $count, '');
			}
			elseif ($field['type'] === 'checkbox')
			{
				$value = array_values(array_filter(array_map('trim', explode(',', $value)), 'strlen'));
			}
			elseif (in_array($field['type'], array('select', 'radio'), true) && $value !== '' && $field['options'] && !in_array($value, $field['options'], true))
			{
				throw new ApiError(400, 'invalid_field', $field['title']);
			}
			if ($name === 'signature')
			{
				$value = self::signatureHtml((string)$raw);
			}
			$vars[$name] = $value;
		}
	}

	/** 닉네임·이메일 바꾸기. 웹과 같이 지금 비밀번호를 확인한다. */
	public static function update()
	{
		$info = self::loggedInfo();
		self::checkPassword($info->member_srl, Core::str('current_password'));

		$vars = self::currentValues($info->member_srl);
		self::applyFields($vars, Core::param('fields'), $info->member_srl);
		// 사이트가 바꾸지 못하게 한 항목은 앱이 보내도 무시한다 (화면에서도 막는다)
		$config = getModel('member')->getMemberConfig();
		$nick_name = self::canChange('nick_name', $config) ? trim(Core::str('nick_name')) : '';
		$email = self::canChange('email_address', $config) ? trim(Core::str('email_address')) : '';
		if ($nick_name !== '')
		{
			$vars['nick_name'] = mb_substr($nick_name, 0, 40);
		}
		if ($email !== '')
		{
			if (!filter_var($email, FILTER_VALIDATE_EMAIL))
			{
				throw new ApiError(400, 'invalid_email', Auth::lang('invalid_email_address'));
			}
			$vars['email_address'] = $email;
		}

		// 엔진이 '비밀번호 확인 단계를 거쳤는지' 보는 표시 (웹은 비밀번호 확인 화면에서 남긴다)
		$_SESSION['rechecked_password_step'] = 'INPUT_DATA';
		if (Core::$engine === 'xe')
		{
			// XE 는 요청 값 전체를 추가 정보로 저장하므로 API 자체의 값(r 등)이 섞이지 않게 비운다
			\Context::getInstance()->get_vars = new \stdClass;
		}
		$vars['module'] = 'member';
		self::run('procMemberModifyInfo', $vars);
		unset($_SESSION['rechecked_password_step']);

		Core::loginAs($info->member_srl); // 바뀐 정보로 다시 읽기
		return Auth::profile();
	}

	/** 비밀번호 바꾸기. 바꾸면 기존 토큰이 모두 무효가 되므로 이 기기에는 새 토큰을 준다. */
	public static function password()
	{
		$info = self::loggedInfo();
		$current = Core::str('current_password');
		$new = Core::str('new_password');
		self::checkPassword($info->member_srl, $current);
		if (mb_strlen($new) < 4)
		{
			throw new ApiError(400, 'invalid_password', Auth::lang('msg_invalid_password'));
		}
		self::run('procMemberModifyPassword', array(
			'module' => 'member',
			'current_password' => $current,
			'password1' => $new,
			'password2' => $new,
		));

		$row = self::memberRow($info->member_srl);
		Tokens::revokeMember($info->member_srl); // 다른 기기의 앱 로그인도 끊는다 (웹에서 비밀번호를 바꿨을 때와 같다)
		$token = Auth::$token ?: array();
		$tokens = Tokens::issue($info->member_srl, $row['password'], $token['device_name'] ?? '', $token['platform'] ?? '');
		return array('tokens' => $tokens);
	}

	/**
	 * 회원 탈퇴: 웹의 [탈퇴]와 같은 엔진 동작 (비밀번호 확인, 관리자는 엔진이 막는다).
	 * 탈퇴하면 이 회원의 앱 로그인(모든 기기의 토큰)도 지운다.
	 */
	public static function leave()
	{
		$info = self::loggedInfo();
		$password = Core::str('password');
		self::checkPassword($info->member_srl, $password);
		self::run('procMemberLeave', array('module' => 'member', 'password' => $password));
		if (self::memberRow($info->member_srl))
		{
			// 엔진이 지우지 않았다 (관리자 등)
			throw new ApiError(400, 'leave_failed', Auth::lang('msg_not_permitted'));
		}
		Tokens::revokeMember($info->member_srl);
		return array('left' => true);
	}

	/**
	 * 프로필 사진 올리기 (multipart, 필드 이름 image) 또는 지우기 (delete=1).
	 * kind 가 image_name·image_mark 면 그 그림 (1.0.21~): 웹 회원정보 수정과 같은 엔진 함수(insertImageName·insertImageMark, 지우기는 procMemberDelete…)
	 */
	public static function image()
	{
		$info = self::loggedInfo();
		$config = getModel('member')->getMemberConfig();
		$kind = Core::str('kind');
		if ($kind === 'image_name' || $kind === 'image_mark')
		{
			return self::extraImage($info, $config, $kind);
		}
		if (!self::profileImageEnabled($config))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		$oController = getController('member');
		if (Core::param('delete'))
		{
			$oController->procMemberDeleteProfileImage($info->member_srl);
		}
		else
		{
			$file = $_FILES['image'] ?? null;
			if (!$file || !is_uploaded_file($file['tmp_name']))
			{
				throw new ApiError(400, 'missing_image', 'image file is required');
			}
			if (!@getimagesize($file['tmp_name']))
			{
				throw new ApiError(400, 'invalid_image', Auth::lang('msg_not_allowed_filetype'));
			}
			$output = $oController->insertProfileImage($info->member_srl, $file['tmp_name']);
			if (is_object($output) && method_exists($output, 'toBool') && !$output->toBool())
			{
				throw new ApiError(400, 'image_failed', Auth::lang($output->getMessage()));
			}
		}
		self::clearCache($info->member_srl);
		Core::loginAs($info->member_srl);
		return Auth::profile();
	}

	private static function extraImage($info, $config, $kind)
	{
		if (!self::formUses($config, $kind))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		$oController = getController('member');
		$suffix = $kind === 'image_name' ? 'ImageName' : 'ImageMark';
		if (Core::param('delete'))
		{
			$oController->{'procMemberDelete' . $suffix}($info->member_srl);
		}
		else
		{
			$file = $_FILES['image'] ?? null;
			if (!$file || !is_uploaded_file($file['tmp_name']))
			{
				throw new ApiError(400, 'missing_image', 'image file is required');
			}
			if (!@getimagesize($file['tmp_name']))
			{
				throw new ApiError(400, 'invalid_image', Auth::lang('msg_not_allowed_filetype'));
			}
			try
			{
				$output = $oController->{'insert' . $suffix}($info->member_srl, $file['tmp_name']);
			}
			catch (\Exception $e)
			{
				throw new ApiError(400, 'image_failed', $e->getMessage());
			}
			if (is_object($output) && method_exists($output, 'toBool') && !$output->toBool())
			{
				throw new ApiError(400, 'image_failed', Auth::lang($output->getMessage()));
			}
		}
		self::clearCache($info->member_srl);
		Core::loginAs($info->member_srl);
		return Auth::profile();
	}

	// ---- 내부

	private static function loggedInfo()
	{
		$info = \Context::get('logged_info');
		if (!$info || !$info->member_srl)
		{
			throw new ApiError(401, 'login_required', Auth::lang('msg_not_logged'));
		}
		return $info;
	}

	private static function checkPassword($member_srl, $password)
	{
		$row = self::memberRow($member_srl);
		$valid = $password !== '' && $row && getModel('member')->isValidPassword($row['password'], $password, $member_srl);
		Write::memberPasswordCheck($member_srl, $valid);
		if (!$valid)
		{
			throw new ApiError(400, 'invalid_password', Auth::lang('invalid_password'));
		}
	}

	private static function memberRow($member_srl)
	{
		$stmt = Core::pdo()->prepare('SELECT * FROM `' . Core::tablePrefix() . 'member` WHERE member_srl = ?');
		$stmt->execute(array($member_srl));
		return $stmt->fetch() ?: null;
	}

	/**
	 * 회원정보 수정 요청에 넣을 지금 값 전부: 가입 양식의 기본 항목, 추가 항목, 서명, 메일·쪽지 수신.
	 */
	private static function currentValues($member_srl)
	{
		$row = self::memberRow($member_srl);
		$config = getModel('member')->getMemberConfig();
		$extra = self::extraVars($row);

		// 기존 추가 정보는 그대로 다시 보낸다 (XE 는 요청에 없는 추가 정보를 지운다)
		$vars = $extra;
		$skip = array('password', 'profile_image', 'image_name', 'image_mark', 'signature', 'find_account_answer');
		foreach ((array)$config->signupForm as $form)
		{
			if (in_array($form->name, $skip, true))
			{
				continue;
			}
			if (!empty($form->isDefaultForm))
			{
				if (array_key_exists($form->name, $row))
				{
					$vars[$form->name] = $row[$form->name];
				}
			}
			elseif (array_key_exists($form->name, $extra))
			{
				$vars[$form->name] = $extra[$form->name];
			}
		}
		foreach (array('allow_mailing', 'allow_message', 'find_account_question') as $name)
		{
			if (isset($row[$name]))
			{
				$vars[$name] = $row[$name];
			}
		}
		$signature = getModel('member')->getSignature($member_srl);
		if ($signature)
		{
			$vars['signature'] = $signature;
		}
		return $vars;
	}

	private static function run($act, array $vars)
	{
		try
		{
			return Board::run('', $act, $vars, false);
		}
		catch (ApiError $e)
		{
			// 엔진이 거절한 이유(닉네임 중복 등)를 그대로 보여 준다
			throw new ApiError(400, 'update_failed', $e->getMessage());
		}
	}

	private static function profileImageEnabled($config)
	{
		if (isset($config->profile_image) && $config->profile_image === 'Y')
		{
			return true;
		}
		foreach ((array)$config->signupForm as $form)
		{
			if ($form->name === 'profile_image' && !empty($form->isUse))
			{
				return true;
			}
		}
		return false;
	}

	private static function clearCache($member_srl)
	{
		$oController = getController('member');
		if (method_exists($oController, '_clearMemberCache'))
		{
			$oController->_clearMemberCache($member_srl);
		}
	}
}
